import { PrismaClient } from '@prisma/client';
import { createHash } from 'crypto';

const prisma = new PrismaClient();

async function main() {
  const newPasswordHash = createHash('sha256').update('admin123').digest('hex');
  
  const user = await prisma.user.update({
    where: { email: 'admin@clinicapsi.com' },
    data: { passwordHash: newPasswordHash }
  });
  
  console.log('Password updated for:', user.email);
  console.log('New hash:', user.passwordHash);
  console.log('\nYou can now login with:');
  console.log('Email: admin@clinicapsi.com');
  console.log('Password: admin123');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
