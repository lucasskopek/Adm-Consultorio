// Simulate browser login flow
async function testBrowserLogin() {
  console.log('=== Testing Browser Login Flow ===\n');
  
  // 1. Visit login page to get cookies
  const loginPageRes = await fetch('http://localhost:3000/login');
  const cookies = loginPageRes.headers.get('set-cookie') || '';
  console.log('1. Got login page, cookies:', cookies.substring(0, 50) + '...');
  
  // 2. Get CSRF token with cookies
  const csrfRes = await fetch('http://localhost:3000/api/auth/csrf', {
    headers: { 'Cookie': cookies }
  });
  const csrfData = await csrfRes.json();
  const newCookies = csrfRes.headers.get('set-cookie') || '';
  const allCookies = [cookies, newCookies].filter(Boolean).join('; ');
  console.log('2. CSRF Token:', csrfData.csrfToken?.substring(0, 20) + '...');
  
  // 3. Get providers
  const providersRes = await fetch('http://localhost:3000/api/auth/providers', {
    headers: { 'Cookie': allCookies }
  });
  const providersData = await providersRes.json();
  console.log('3. Providers:', Object.keys(providersData));
  
  // 4. Submit login form
  console.log('\n4. Submitting login...');
  const loginRes = await fetch('http://localhost:3000/api/auth/callback/credentials', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Cookie': allCookies,
    },
    body: new URLSearchParams({
      email: 'admin@clinicapsi.com',
      password: 'admin123',
      csrfToken: csrfData.csrfToken,
      callbackUrl: 'http://localhost:3000',
    }).toString(),
    redirect: 'manual'
  });
  
  console.log('   Status:', loginRes.status);
  const loginCookies = loginRes.headers.get('set-cookie') || '';
  console.log('   New cookies:', loginCookies.substring(0, 100) + '...');
  
  // 5. Check session with new cookies
  const finalCookies = [allCookies, loginCookies].filter(Boolean).join('; ');
  const sessionRes = await fetch('http://localhost:3000/api/auth/session', {
    headers: { 'Cookie': finalCookies }
  });
  const sessionData = await sessionRes.json();
  console.log('\n5. Final session:', sessionData);
}

testBrowserLogin().catch(console.error);
