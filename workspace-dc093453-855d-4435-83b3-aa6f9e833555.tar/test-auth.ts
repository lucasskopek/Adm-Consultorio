import { PrismaClient } from '@prisma/client';
import { createHash } from 'crypto';

const prisma = new PrismaClient();

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

async function main() {
  console.log('=== Testing Authentication ===\n');
  
  const email = 'admin@clinicapsi.com';
  const password = 'admin123';
  
  // Get user
  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() }
  });
  
  if (!user) {
    console.log('❌ User not found');
    return;
  }
  
  console.log('✅ User found:', user.email);
  console.log('   Name:', user.name);
  
  // Test password
  const passwordHash = hashPassword(password);
  console.log('\nPassword test:');
  console.log('   Input password:', password);
  console.log('   Computed hash:', passwordHash);
  console.log('   Stored hash:  ', user.passwordHash);
  console.log('   Match:', passwordHash === user.passwordHash ? '✅ YES' : '❌ NO');
  
  // If not matching, update the password
  if (passwordHash !== user.passwordHash) {
    console.log('\n🔧 Updating password hash...');
    await prisma.user.update({
      where: { email: email },
      data: { passwordHash: passwordHash }
    });
    console.log('✅ Password updated! Try logging in again.');
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
