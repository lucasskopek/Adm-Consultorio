// Test login flow
async function testLogin() {
  console.log('=== Testing Login Flow ===\n');
  
  // 1. Get CSRF token
  const csrfRes = await fetch('http://localhost:3000/api/auth/csrf');
  const csrfData = await csrfRes.json();
  console.log('1. CSRF Token:', csrfData.csrfToken?.substring(0, 20) + '...');
  
  // 2. Try to login
  const loginRes = await fetch('http://localhost:3000/api/auth/callback/credentials', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      email: 'admin@clinicapsi.com',
      password: 'admin123',
      csrfToken: csrfData.csrfToken,
      callbackUrl: 'http://localhost:3000',
      json: 'true'
    }).toString()
  });
  
  console.log('2. Login Response Status:', loginRes.status);
  console.log('   Headers:', Object.fromEntries(loginRes.headers.entries()));
  
  const loginText = await loginRes.text();
  console.log('   Body:', loginText.substring(0, 200));
  
  // 3. Check session
  const sessionRes = await fetch('http://localhost:3000/api/auth/session');
  const sessionData = await sessionRes.json();
  console.log('3. Session:', sessionData);
}

testLogin().catch(console.error);
