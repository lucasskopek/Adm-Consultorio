'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar } from '@/components/ui/calendar';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus,
  Clock,
  Video,
  Phone,
  MapPin,
  User
} from 'lucide-react';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, addWeeks, subWeeks, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/lib/store/app-store';

interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  startTime: string;
  endTime: string;
  type: 'presencial' | 'online' | 'telefone';
  status: 'scheduled' | 'confirmed' | 'cancelled' | 'completed' | 'no_show';
  isRecurring: boolean;
}

// Generate mock appointments for demo
const generateMockAppointments = (): Appointment[] => {
  const appointments: Appointment[] = [];
  const patients = ['Ana Silva', 'Carlos Mendes', 'Beatriz Costa', 'Daniel Oliveira', 'Elena Santos'];
  const types: Appointment['type'][] = ['presencial', 'online', 'telefone'];
  const statuses: Appointment['status'][] = ['confirmed', 'pending', 'scheduled'];
  
  const today = new Date();
  
  for (let dayOffset = -7; dayOffset <= 14; dayOffset++) {
    const date = new Date(today);
    date.setDate(date.getDate() + dayOffset);
    
    // Generate 5-8 appointments per day
    const numAppointments = 5 + Math.floor(Math.random() * 4);
    let hour = 8;
    
    for (let i = 0; i < numAppointments && hour < 19; i++) {
      const startHour = hour;
      const endHour = hour + 1;
      
      appointments.push({
        id: `${date.toISOString()}-${hour}`,
        patientId: `patient-${Math.floor(Math.random() * patients.length)}`,
        patientName: patients[Math.floor(Math.random() * patients.length)],
        startTime: new Date(date.setHours(startHour, 0, 0, 0)).toISOString(),
        endTime: new Date(date.setHours(endHour, 0, 0, 0)).toISOString(),
        type: types[Math.floor(Math.random() * types.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
        isRecurring: Math.random() > 0.7,
      });
      
      hour += 1 + Math.floor(Math.random() * 2);
    }
  }
  
  return appointments;
};

const mockAppointments = generateMockAppointments();

const typeIcons = {
  presencial: MapPin,
  online: Video,
  telefone: Phone,
};

const statusColors = {
  confirmed: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-green-200 dark:border-green-800',
  pending: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800',
  scheduled: 'bg-primary/10 text-primary border-primary/20',
  cancelled: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800',
  completed: 'bg-muted text-muted-foreground border-border',
  no_show: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800',
};

function WeekView({ 
  selectedDate, 
  appointments,
  onSelectDate 
}: { 
  selectedDate: Date; 
  appointments: Appointment[];
  onSelectDate: (date: Date) => void;
}) {
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });
  
  const hours = Array.from({ length: 12 }, (_, i) => i + 8); // 8:00 - 19:00

  const getAppointmentsForDay = (date: Date) => {
    return appointments.filter(apt => isSameDay(new Date(apt.startTime), date));
  };

  const getAppointmentForHour = (date: Date, hour: number) => {
    return appointments.find(apt => {
      const aptDate = new Date(apt.startTime);
      return isSameDay(aptDate, date) && aptDate.getHours() === hour;
    });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Week Header */}
      <div className="grid grid-cols-8 border-b">
        <div className="p-2 text-xs text-muted-foreground border-r">Hora</div>
        {weekDays.map((day) => (
          <div 
            key={day.toISOString()} 
            className={cn(
              'p-2 text-center border-r last:border-r-0 cursor-pointer hover:bg-muted/50',
              isToday(day) && 'bg-primary/5'
            )}
            onClick={() => onSelectDate(day)}
          >
            <p className="text-xs text-muted-foreground capitalize">
              {format(day, 'EEE', { locale: ptBR })}
            </p>
            <p className={cn(
              'text-sm font-semibold',
              isToday(day) && 'text-primary'
            )}>
              {format(day, 'd')}
            </p>
          </div>
        ))}
      </div>

      {/* Week Body */}
      <ScrollArea className="flex-1">
        <div className="grid grid-cols-8 min-h-[600px]">
          {/* Time Column */}
          <div className="border-r">
            {hours.map((hour) => (
              <div 
                key={hour} 
                className="h-16 p-1 text-xs text-muted-foreground text-right pr-2 border-b"
              >
                {hour.toString().padStart(2, '0')}:00
              </div>
            ))}
          </div>

          {/* Days Columns */}
          {weekDays.map((day) => (
            <div key={day.toISOString()} className="border-r last:border-r-0 relative">
              {hours.map((hour) => {
                const apt = getAppointmentForHour(day, hour);
                const TypeIcon = apt ? typeIcons[apt.type] : null;
                
                return (
                  <div 
                    key={hour} 
                    className={cn(
                      'h-16 border-b p-1',
                      isToday(day) && 'bg-muted/30'
                    )}
                  >
                    {apt && (
                      <div 
                        className={cn(
                          'h-full rounded-md p-1 cursor-pointer transition-colors border',
                          statusColors[apt.status]
                        )}
                      >
                        <div className="flex items-center gap-1">
                          <TypeIcon className="h-3 w-3" />
                          <span className="text-xs font-medium truncate">
                            {apt.patientName.split(' ')[0]}
                          </span>
                        </div>
                        <p className="text-[10px] truncate">
                          {format(new Date(apt.startTime), 'HH:mm')} - {format(new Date(apt.endTime), 'HH:mm')}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

function DayView({ 
  selectedDate, 
  appointments 
}: { 
  selectedDate: Date; 
  appointments: Appointment[];
}) {
  const dayAppointments = appointments
    .filter(apt => isSameDay(new Date(apt.startTime), selectedDate))
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());

  return (
    <ScrollArea className="flex-1 h-[600px]">
      <div className="space-y-2 p-2">
        {dayAppointments.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            Nenhuma sessão agendada para este dia
          </div>
        ) : (
          dayAppointments.map((apt) => {
            const TypeIcon = typeIcons[apt.type];
            return (
              <Card key={apt.id} className={cn('cursor-pointer hover:shadow-md transition-shadow', statusColors[apt.status])}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-16 text-center">
                      <p className="text-sm font-semibold">
                        {format(new Date(apt.startTime), 'HH:mm')}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(apt.endTime), 'HH:mm')}
                      </p>
                    </div>
                    
                    <div className="flex-1">
                      <p className="font-medium">{apt.patientName}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <TypeIcon className="h-3 w-3" />
                        <span className="capitalize">{apt.type}</span>
                        {apt.isRecurring && (
                          <Badge variant="outline" className="text-[10px]">
                            Recorrente
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <Badge variant="secondary" className="capitalize">
                      {apt.status === 'pending' ? 'Pendente' : 
                       apt.status === 'confirmed' ? 'Confirmada' : 
                       apt.status === 'scheduled' ? 'Agendada' : apt.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </ScrollArea>
  );
}

export function CalendarView() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState<'day' | 'week' | 'month'>('week');
  const { setNewSessionModalOpen } = useUIStore();

  const navigateWeek = (direction: 'prev' | 'next') => {
    setSelectedDate(prev => 
      direction === 'next' ? addWeeks(prev, 1) : subWeeks(prev, 1)
    );
  };

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div className="flex items-center gap-2">
          <CardTitle className="text-lg font-semibold">Agenda</CardTitle>
          <Badge variant="outline" className="capitalize">{view}</Badge>
        </div>
        
        <div className="flex items-center gap-2">
          {/* View Toggle */}
          <div className="flex items-center border rounded-lg p-1">
            <Button 
              variant={view === 'day' ? 'secondary' : 'ghost'} 
              size="sm"
              onClick={() => setView('day')}
            >
              Dia
            </Button>
            <Button 
              variant={view === 'week' ? 'secondary' : 'ghost'} 
              size="sm"
              onClick={() => setView('week')}
            >
              Semana
            </Button>
            <Button 
              variant={view === 'month' ? 'secondary' : 'ghost'} 
              size="sm"
              onClick={() => setView('month')}
            >
              Mês
            </Button>
          </div>

          {/* Navigation */}
          {view !== 'month' && (
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => navigateWeek('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setSelectedDate(new Date())}
              >
                Hoje
              </Button>
              <Button variant="ghost" size="icon" onClick={() => navigateWeek('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}

          {/* New Session Button */}
          <Button onClick={() => setNewSessionModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nova Sessão
          </Button>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {view === 'month' ? (
          <div className="p-4">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              className="rounded-md border"
              locale={ptBR}
            />
          </div>
        ) : view === 'week' ? (
          <WeekView 
            selectedDate={selectedDate} 
            appointments={mockAppointments}
            onSelectDate={setSelectedDate}
          />
        ) : (
          <DayView selectedDate={selectedDate} appointments={mockAppointments} />
        )}
      </CardContent>
    </Card>
  );
}
