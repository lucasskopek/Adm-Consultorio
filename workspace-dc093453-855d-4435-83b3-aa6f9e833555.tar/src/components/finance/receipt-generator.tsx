'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Receipt,
  Download,
  Printer,
  Mail,
  CheckCircle,
  DollarSign,
  Calendar,
  User,
  FileText
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

interface ReceiptGeneratorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payment?: {
    id: string;
    patientName: string;
    amount: number;
    date: string;
    sessions: number;
  };
}

export function ReceiptGenerator({ open, onOpenChange, payment }: ReceiptGeneratorProps) {
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  // Receipt data
  const [therapistName] = useState('Dra. Maria Silva');
  const [therapistCRP] = useState('CRP 06/123456');
  const [therapistAddress] = useState('Rua das Flores, 123 - São Paulo, SP');
  const [therapistCPF] = useState('123.456.789-00');
  
  const [receiptNumber, setReceiptNumber] = useState('001234');
  const [patientName, setPatientName] = useState(payment?.patientName || '');
  const [patientCPF, setPatientCPF] = useState('');
  const [amount, setAmount] = useState(payment?.amount?.toString() || '200');
  const [sessions, setSessions] = useState(payment?.sessions?.toString() || '1');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [description, setDescription] = useState('Serviços de psicoterapia');

  const handleGenerate = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setGenerated(true);
    setLoading(false);
    toast.success('Recibo gerado com sucesso!');
  };

  const handleDownload = () => {
    // Generate PDF content
    const receiptContent = `
RECIBO Nº ${receiptNumber}

Recebi de ${patientName}, CPF: ${patientCPF || 'Não informado'},
a quantia de R$ ${parseFloat(amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })} 
(${numberToWords(parseFloat(amount))} reais),
referente a ${sessions} sessão(ões) de ${description}.

Data: ${format(new Date(date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}

_________________________________
${therapistName}
${therapistCRP}
CPF: ${therapistCPF}
${therapistAddress}
    `;
    
    // Create blob and download
    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recibo-${receiptNumber}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Recibo baixado!');
  };

  const handlePrint = () => {
    window.print();
    toast.success('Enviando para impressão...');
  };

  const handleEmail = () => {
    toast.success('Recibo enviado por e-mail!');
  };

  // Helper function to convert numbers to words (simplified)
  const numberToWords = (num: number): string => {
    const units = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove'];
    const tens = ['', 'dez', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
    const hundreds = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
    
    if (num < 10) return units[num];
    if (num < 100) return tens[Math.floor(num / 10)] + (num % 10 ? ' e ' + units[num % 10] : '');
    if (num < 1000) return hundreds[Math.floor(num / 100)] + (num % 100 ? ' e ' + numberToWords(num % 100) : '');
    if (num < 10000) return numberToWords(Math.floor(num / 1000)) + ' mil' + (num % 1000 ? ' ' + numberToWords(num % 1000) : '');
    
    return num.toString();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Receipt className="h-5 w-5" />
            Gerar Recibo
          </DialogTitle>
          <DialogDescription>
            Preencha os dados para gerar o recibo
          </DialogDescription>
        </DialogHeader>

        {!generated ? (
          <div className="grid gap-4 py-4">
            {/* Receipt Number */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Número do Recibo</Label>
                <Input 
                  value={receiptNumber} 
                  onChange={(e) => setReceiptNumber(e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label>Data</Label>
                <Input 
                  type="date"
                  value={date} 
                  onChange={(e) => setDate(e.target.value)} 
                />
              </div>
            </div>

            {/* Patient Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nome do Paciente</Label>
                <Input 
                  value={patientName} 
                  onChange={(e) => setPatientName(e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label>CPF do Paciente</Label>
                <Input 
                  value={patientCPF} 
                  onChange={(e) => setPatientCPF(e.target.value)} 
                  placeholder="000.000.000-00"
                />
              </div>
            </div>

            {/* Value Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Valor (R$)</Label>
                <Input 
                  type="number"
                  value={amount} 
                  onChange={(e) => setAmount(e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label>Número de Sessões</Label>
                <Input 
                  type="number"
                  value={sessions} 
                  onChange={(e) => setSessions(e.target.value)} 
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label>Descrição</Label>
              <Input 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
              />
            </div>

            {/* Preview */}
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm space-y-1">
                  <p className="font-medium">Pré-visualização:</p>
                  <p>Recebi de <strong>{patientName || '...'}</strong></p>
                  <p>a quantia de <strong>R$ {parseFloat(amount || '0').toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong></p>
                  <p>referente a <strong>{sessions || '0'} sessão(ões)</strong> de {description}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="py-4">
            {/* Generated Receipt Preview */}
            <Card className="border-2">
              <CardContent className="pt-6 space-y-4">
                <div className="text-center border-b pb-4">
                  <h3 className="text-xl font-bold">{therapistName}</h3>
                  <p className="text-sm text-muted-foreground">{therapistCRP}</p>
                  <p className="text-sm text-muted-foreground">{therapistAddress}</p>
                </div>
                
                <div className="text-center">
                  <Badge variant="outline" className="text-lg px-4 py-1">
                    RECIBO Nº {receiptNumber}
                  </Badge>
                </div>

                <div className="space-y-4 text-sm">
                  <p>
                    Recebi de <strong>{patientName}</strong>, 
                    CPF: {patientCPF || 'Não informado'},
                  </p>
                  <p>
                    a quantia de <strong className="text-lg">
                      R$ {parseFloat(amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </strong>
                  </p>
                  <p className="text-muted-foreground italic">
                    ({numberToWords(parseFloat(amount))} reais)
                  </p>
                  <p>
                    referente a <strong>{sessions} sessão(ões)</strong> de {description}.
                  </p>
                  <p className="pt-4">
                    {format(new Date(date), "'São Paulo, dd 'de' MMMM 'de' yyyy'.'", { locale: ptBR })}
                  </p>
                </div>

                <div className="pt-8 text-center">
                  <p className="border-t pt-4 inline-block px-8">
                    _________________________________________________
                  </p>
                  <p className="font-medium">{therapistName}</p>
                  <p className="text-sm text-muted-foreground">{therapistCRP}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <DialogFooter className="flex-col sm:flex-row gap-2">
          {!generated ? (
            <>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button onClick={handleGenerate} disabled={loading}>
                {loading ? 'Gerando...' : 'Gerar Recibo'}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setGenerated(false)}>
                Editar
              </Button>
              <Button variant="outline" onClick={handleEmail}>
                <Mail className="h-4 w-4 mr-2" />
                Enviar E-mail
              </Button>
              <Button variant="outline" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-2" />
                Imprimir
              </Button>
              <Button onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                Baixar
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
