'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download,
  Filter,
  Search,
  Receipt,
  CreditCard,
  Banknote,
  Smartphone,
  AlertCircle,
  CheckCircle,
  Clock,
  MoreVertical,
  FileText,
  Send
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Payment {
  id: string;
  patientId: string;
  patientName: string;
  amount: number;
  method: 'cash' | 'credit' | 'debit' | 'pix' | 'transfer';
  status: 'pending' | 'paid' | 'cancelled' | 'refunded';
  dueDate: string;
  paidAt: string | null;
  referenceMonth: string;
  sessionIds: string[];
}

const mockPayments: Payment[] = [
  {
    id: '1',
    patientId: 'p1',
    patientName: 'Ana Silva',
    amount: 400,
    method: 'pix',
    status: 'paid',
    dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    referenceMonth: '2024-01',
    sessionIds: ['s1', 's2'],
  },
  {
    id: '2',
    patientId: 'p2',
    patientName: 'Carlos Mendes',
    amount: 600,
    method: 'credit',
    status: 'pending',
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: null,
    referenceMonth: '2024-01',
    sessionIds: ['s3', 's4', 's5'],
  },
  {
    id: '3',
    patientId: 'p3',
    patientName: 'Beatriz Costa',
    amount: 800,
    method: 'transfer',
    status: 'paid',
    dueDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    referenceMonth: '2024-01',
    sessionIds: ['s6', 's7', 's8', 's9'],
  },
  {
    id: '4',
    patientId: 'p4',
    patientName: 'Daniel Oliveira',
    amount: 750,
    method: 'cash',
    status: 'pending',
    dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: null,
    referenceMonth: '2024-01',
    sessionIds: ['s10', 's11'],
  },
  {
    id: '5',
    patientId: 'p5',
    patientName: 'Elena Santos',
    amount: 1200,
    method: 'pix',
    status: 'paid',
    dueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    referenceMonth: '2024-01',
    sessionIds: ['s12', 's13', 's14', 's15', 's16', 's17'],
  },
  {
    id: '6',
    patientId: 'p2',
    patientName: 'Carlos Mendes',
    amount: 400,
    method: 'pix',
    status: 'pending',
    dueDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: null,
    referenceMonth: '2024-01',
    sessionIds: ['s18', 's19'],
  },
];

const methodConfig = {
  cash: { label: 'Dinheiro', icon: Banknote, color: 'text-green-600' },
  credit: { label: 'Crédito', icon: CreditCard, color: 'text-purple-600' },
  debit: { label: 'Débito', icon: CreditCard, color: 'text-blue-600' },
  pix: { label: 'PIX', icon: Smartphone, color: 'text-teal-600' },
  transfer: { label: 'Transferência', icon: Banknote, color: 'text-orange-600' },
};

const statusConfig = {
  pending: { label: 'Pendente', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', icon: Clock },
  paid: { label: 'Pago', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', icon: CheckCircle },
  cancelled: { label: 'Cancelado', color: 'bg-muted text-muted-foreground', icon: AlertCircle },
  refunded: { label: 'Reembolsado', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', icon: AlertCircle },
};

function PaymentRow({ payment }: { payment: Payment }) {
  const method = methodConfig[payment.method];
  const status = statusConfig[payment.status];
  const MethodIcon = method.icon;
  const StatusIcon = status.icon;
  const isOverdue = payment.status === 'pending' && new Date(payment.dueDate) < new Date();

  return (
    <TableRow className={cn(isOverdue && 'bg-red-50 dark:bg-red-900/10')}>
      <TableCell>
        <div className="flex items-center gap-3">
          <div>
            <p className="font-medium">{payment.patientName}</p>
            <p className="text-xs text-muted-foreground">
              {payment.sessionIds.length} sessão(ões)
            </p>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          <MethodIcon className={cn('h-4 w-4', method.color)} />
          <span className="text-sm">{method.label}</span>
        </div>
      </TableCell>
      <TableCell className="text-right font-medium">
        R$ {payment.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
      </TableCell>
      <TableCell>
        <p className="text-sm">{format(new Date(payment.dueDate), 'dd/MM/yyyy')}</p>
        {isOverdue && (
          <p className="text-xs text-red-600 dark:text-red-400">Vencido</p>
        )}
      </TableCell>
      <TableCell>
        {payment.paidAt ? (
          <p className="text-sm">{format(new Date(payment.paidAt), 'dd/MM/yyyy')}</p>
        ) : (
          <span className="text-muted-foreground">-</span>
        )}
      </TableCell>
      <TableCell>
        <Badge variant="secondary" className={cn('gap-1', status.color)}>
          <StatusIcon className="h-3 w-3" />
          {status.label}
        </Badge>
      </TableCell>
      <TableCell>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {payment.status === 'pending' && (
              <>
                <DropdownMenuItem>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Marcar como Pago
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Send className="h-4 w-4 mr-2" />
                  Enviar Lembrete
                </DropdownMenuItem>
              </>
            )}
            <DropdownMenuItem>
              <Receipt className="h-4 w-4 mr-2" />
              Gerar Recibo
            </DropdownMenuItem>
            <DropdownMenuItem>
              <FileText className="h-4 w-4 mr-2" />
              Detalhes
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </TableCell>
    </TableRow>
  );
}

export function FinanceOverview() {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const stats = useMemo(() => {
    const now = new Date();
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    const monthPayments = mockPayments.filter(p => 
      isWithinInterval(new Date(p.dueDate), { start: monthStart, end: monthEnd })
    );

    const received = monthPayments
      .filter(p => p.status === 'paid')
      .reduce((acc, p) => acc + p.amount, 0);

    const pending = mockPayments
      .filter(p => p.status === 'pending')
      .reduce((acc, p) => acc + p.amount, 0);

    const overdue = mockPayments
      .filter(p => p.status === 'pending' && new Date(p.dueDate) < now)
      .reduce((acc, p) => acc + p.amount, 0);

    return { received, pending, overdue };
  }, []);

  const filteredPayments = useMemo(() => {
    let result = [...mockPayments];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p => p.patientName.toLowerCase().includes(query));
    }

    if (statusFilter !== 'all') {
      result = result.filter(p => p.status === statusFilter);
    }

    return result.sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());
  }, [searchQuery, statusFilter]);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Recebido este mês</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  R$ {stats.received.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-full bg-green-100 dark:bg-green-900/30">
                <TrendingUp className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pendente</p>
                <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                  R$ {stats.pending.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-full bg-amber-100 dark:bg-amber-900/30">
                <Clock className="h-6 w-6 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Vencido</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  R$ {stats.overdue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-full bg-red-100 dark:bg-red-900/30">
                <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payments Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg font-semibold">Pagamentos</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
            <Button size="sm">
              <Receipt className="h-4 w-4 mr-2" />
              Novo Pagamento
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar paciente..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[160px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="paid">Pago</SelectItem>
                <SelectItem value="cancelled">Cancelado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Paciente</TableHead>
                  <TableHead>Método</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Pago em</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayments.map((payment) => (
                  <PaymentRow key={payment.id} payment={payment} />
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
