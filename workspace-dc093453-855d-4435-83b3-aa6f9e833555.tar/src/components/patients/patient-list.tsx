'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Search, 
  Plus, 
  Filter,
  MoreVertical,
  Eye,
  FileText,
  Calendar,
  Phone,
  Mail,
  SortAsc
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Patient {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  initials: string;
  birthDate: string | null;
  lastSession: string | null;
  nextSession: string | null;
  totalSessions: number;
  status: 'active' | 'inactive' | 'waiting_list';
  unpaidSessions: number;
}

const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'Ana Silva',
    email: 'ana.silva@email.com',
    phone: '(11) 98765-4321',
    initials: 'AS',
    birthDate: '1985-03-15',
    lastSession: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 45,
    status: 'active',
    unpaidSessions: 0,
  },
  {
    id: '2',
    name: 'Carlos Mendes',
    email: 'carlos.mendes@email.com',
    phone: '(11) 91234-5678',
    initials: 'CM',
    birthDate: '1990-07-22',
    lastSession: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: null,
    totalSessions: 23,
    status: 'active',
    unpaidSessions: 2,
  },
  {
    id: '3',
    name: 'Beatriz Costa',
    email: 'beatriz.costa@email.com',
    phone: '(11) 92345-6789',
    initials: 'BC',
    birthDate: '1978-11-08',
    lastSession: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 67,
    status: 'active',
    unpaidSessions: 0,
  },
  {
    id: '4',
    name: 'Daniel Oliveira',
    email: 'daniel.oliveira@email.com',
    phone: '(11) 93456-7890',
    initials: 'DO',
    birthDate: '1995-02-28',
    lastSession: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: null,
    totalSessions: 12,
    status: 'inactive',
    unpaidSessions: 3,
  },
  {
    id: '5',
    name: 'Elena Santos',
    email: 'elena.santos@email.com',
    phone: '(11) 94567-8901',
    initials: 'ES',
    birthDate: '1982-09-10',
    lastSession: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 89,
    status: 'active',
    unpaidSessions: 0,
  },
  {
    id: '6',
    name: 'Fernando Lima',
    email: 'fernando.lima@email.com',
    phone: '(11) 95678-9012',
    initials: 'FL',
    birthDate: '1988-05-20',
    lastSession: null,
    nextSession: null,
    totalSessions: 0,
    status: 'waiting_list',
    unpaidSessions: 0,
  },
  {
    id: '7',
    name: 'Gabriela Ferreira',
    email: 'gabriela.ferreira@email.com',
    phone: '(11) 96789-0123',
    initials: 'GF',
    birthDate: '1992-12-03',
    lastSession: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    nextSession: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 34,
    status: 'active',
    unpaidSessions: 1,
  },
];

const statusConfig = {
  active: { label: 'Ativo', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
  inactive: { label: 'Inativo', color: 'bg-muted text-muted-foreground' },
  waiting_list: { label: 'Lista de Espera', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' },
};

interface PatientListProps {
  onPatientClick?: (patientId: string) => void;
}

function PatientCard({ patient, onClick }: { patient: Patient; onClick?: () => void }) {
  const status = statusConfig[patient.status];

  return (
    <Card className="group hover:shadow-md transition-shadow cursor-pointer" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-primary/10 text-primary font-medium text-lg">
              {patient.initials}
            </AvatarFallback>
          </Avatar>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold truncate">{patient.name}</h3>
              <Badge variant="secondary" className={cn('text-xs', status.color)}>
                {status.label}
              </Badge>
            </div>

            <div className="space-y-1">
              {patient.email && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span className="truncate">{patient.email}</span>
                </div>
              )}
              {patient.phone && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Phone className="h-3 w-3" />
                  <span>{patient.phone}</span>
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-4 mt-2 pt-2 border-t">
              <div>
                <p className="text-xs text-muted-foreground">Sessões</p>
                <p className="text-sm font-medium">{patient.totalSessions}</p>
              </div>
              {patient.unpaidSessions > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground">Pendências</p>
                  <p className="text-sm font-medium text-destructive">{patient.unpaidSessions}</p>
                </div>
              )}
              {patient.nextSession && (
                <div>
                  <p className="text-xs text-muted-foreground">Próxima</p>
                  <p className="text-sm font-medium">
                    {format(new Date(patient.nextSession), "dd/MM 'às' HH:mm", { locale: ptBR })}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Eye className="h-4 w-4 mr-2" />
                Ver Prontuário
              </DropdownMenuItem>
              <DropdownMenuItem>
                <FileText className="h-4 w-4 mr-2" />
                Nova Anotação
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Calendar className="h-4 w-4 mr-2" />
                Agendar Sessão
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Editar Paciente</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}

export function PatientList({ onPatientClick }: PatientListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('name');

  const filteredPatients = useMemo(() => {
    let result = [...mockPatients];

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.email?.toLowerCase().includes(query) ||
        p.phone?.includes(query)
      );
    }

    // Filter by status
    if (statusFilter !== 'all') {
      result = result.filter(p => p.status === statusFilter);
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'sessions') return b.totalSessions - a.totalSessions;
      if (sortBy === 'lastSession') {
        if (!a.lastSession) return 1;
        if (!b.lastSession) return -1;
        return new Date(b.lastSession).getTime() - new Date(a.lastSession).getTime();
      }
      return 0;
    });

    return result;
  }, [searchQuery, statusFilter, sortBy]);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar por nome, email ou telefone..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Status Filter */}
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[160px]">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
            <SelectItem value="waiting_list">Lista de Espera</SelectItem>
          </SelectContent>
        </Select>

        {/* Sort */}
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-full sm:w-[160px]">
            <SortAsc className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Ordenar" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Nome</SelectItem>
            <SelectItem value="sessions">Sessões</SelectItem>
            <SelectItem value="lastSession">Última Sessão</SelectItem>
          </SelectContent>
        </Select>

        {/* Add Patient Button */}
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          Novo Paciente
        </Button>
      </div>

      {/* Results Count */}
      <div className="text-sm text-muted-foreground">
        {filteredPatients.length} paciente(s) encontrado(s)
      </div>

      {/* Patient Grid */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filteredPatients.map((patient) => (
          <PatientCard 
            key={patient.id} 
            patient={patient} 
            onClick={() => onPatientClick?.(patient.id)}
          />
        ))}
      </div>

      {filteredPatients.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhum paciente encontrado</p>
        </div>
      )}
    </div>
  );
}
