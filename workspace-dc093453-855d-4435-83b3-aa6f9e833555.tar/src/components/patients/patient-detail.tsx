'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  ArrowLeft,
  User,
  FileText,
  Calendar,
  DollarSign,
  Phone,
  Mail,
  MapPin,
  Clock,
  Edit,
  Plus,
  Lock,
  Unlock,
  Download,
  Trash2,
  MoreVertical
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface PatientDetailProps {
  patientId: string;
  onBack: () => void;
}

// Mock patient data
const mockPatient = {
  id: '1',
  name: 'Ana Silva',
  email: 'ana.silva@email.com',
  phone: '(11) 98765-4321',
  birthDate: '1985-03-15',
  gender: 'female',
  cpf: '123.456.789-00',
  address: 'Rua das Flores, 123',
  city: 'São Paulo',
  state: 'SP',
  emergencyName: 'Maria Silva',
  emergencyPhone: '(11) 91234-5678',
  emergencyRelation: 'Mãe',
  occupation: 'Advogada',
  maritalStatus: 'married',
  status: 'active',
  totalSessions: 45,
  unpaidSessions: 0,
  lastSession: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  nextSession: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
  createdAt: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
  lgpdConsent: true,
  lgpdConsentAt: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
};

const mockAnamnesis = {
  mainComplaint: 'Ansiedade e dificuldade de relacionamento',
  diseaseHistory: 'Sintomas iniciaram há aproximadamente 2 anos, após separação conjugal',
  familyHistory: 'Pai com histórico de depressão. Mãe ansiosa. Irmão mais novo sem queixas.',
  personalHistory: 'Infância marcada por conflitos familiares. Casou-se aos 25 anos, separou-se aos 35.',
  medicalHistory: 'Nega doenças crônicas. Usa anticoncepcional oral.',
  medications: 'Anticoncepcional oral',
  previousTreatments: 'Fez terapia por 6 meses em 2020, interrompeu por questões financeiras.',
  expectations: 'Entender padrões de relacionamento e lidar melhor com ansiedade.',
  notes: 'Paciente motivada para o processo analítico.',
};

const mockSessions = [
  { id: '1', number: 45, date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), status: 'completed', paid: true },
  { id: '2', number: 44, date: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(), status: 'completed', paid: true },
  { id: '3', number: 43, date: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000).toISOString(), status: 'completed', paid: true },
  { id: '4', number: 42, date: new Date(Date.now() - 23 * 24 * 60 * 60 * 1000).toISOString(), status: 'completed', paid: true },
  { id: '5', number: 41, date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), status: 'completed', paid: true },
];

const mockNotes = [
  { id: '1', type: 'clinical', title: 'Sessão 45', date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), encrypted: true },
  { id: '2', type: 'clinical', title: 'Sessão 44', date: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(), encrypted: true },
  { id: '3', type: 'administrative', title: 'Observação', date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), encrypted: false },
];

const mockAttachments = [
  { id: '1', name: 'Exames laboratoriais.pdf', type: 'exam', size: 256000, uploadedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '2', name: 'Receita médico.pdf', type: 'document', size: 128000, uploadedAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString() },
];

export function PatientDetail({ patientId, onBack }: PatientDetailProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isNotesLocked, setIsNotesLocked] = useState(true);

  const patient = mockPatient;
  const anamnesis = mockAnamnesis;

  const age = patient.birthDate 
    ? Math.floor((new Date().getTime() - new Date(patient.birthDate).getTime()) / (365.25 * 24 * 60 * 60 * 1000))
    : null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{patient.name}</h1>
              <Badge variant={patient.status === 'active' ? 'default' : 'secondary'}>
                {patient.status === 'active' ? 'Ativo' : 'Inativo'}
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Paciente desde {format(new Date(patient.createdAt), "MMMM 'de' yyyy", { locale: ptBR })}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Agendar
          </Button>
          <Button>
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total de Sessões</span>
            </div>
            <p className="text-2xl font-bold mt-1">{patient.totalSessions}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Última Sessão</span>
            </div>
            <p className="text-2xl font-bold mt-1">
              {formatDistanceToNow(new Date(patient.lastSession), { addSuffix: true, locale: ptBR })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Próxima Sessão</span>
            </div>
            <p className="text-2xl font-bold mt-1">
              {format(new Date(patient.nextSession), "dd/MM 'às' HH:mm", { locale: ptBR })}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Pendências</span>
            </div>
            <p className="text-2xl font-bold mt-1">
              {patient.unpaidSessions > 0 ? `${patient.unpaidSessions} sessões` : 'Nenhuma'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="anamnesis">Anamnese</TabsTrigger>
          <TabsTrigger value="sessions">Sessões</TabsTrigger>
          <TabsTrigger value="notes">Notas</TabsTrigger>
          <TabsTrigger value="attachments">Anexos</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Personal Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Dados Pessoais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Idade</p>
                    <p className="font-medium">{age ? `${age} anos` : 'Não informado'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">E-mail</p>
                    <p className="font-medium">{patient.email || 'Não informado'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Telefone</p>
                    <p className="font-medium">{patient.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Endereço</p>
                    <p className="font-medium">{patient.address}, {patient.city} - {patient.state}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contato de Emergência</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Nome</p>
                  <p className="font-medium">{patient.emergencyName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Telefone</p>
                  <p className="font-medium">{patient.emergencyPhone}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Parentesco</p>
                  <p className="font-medium">{patient.emergencyRelation}</p>
                </div>
              </CardContent>
            </Card>

            {/* Additional Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Informações Adicionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Profissão</p>
                  <p className="font-medium">{patient.occupation}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estado Civil</p>
                  <p className="font-medium capitalize">
                    {patient.maritalStatus === 'married' ? 'Casado(a)' : 
                     patient.maritalStatus === 'single' ? 'Solteiro(a)' : 
                     patient.maritalStatus === 'divorced' ? 'Divorciado(a)' : patient.maritalStatus}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">CPF</p>
                  <p className="font-medium">{patient.cpf}</p>
                </div>
              </CardContent>
            </Card>

            {/* LGPD Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">LGPD</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  {patient.lgpdConsent ? (
                    <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                      Consentimento Obtido
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      Consentimento Pendente
                    </Badge>
                  )}
                </div>
                {patient.lgpdConsentAt && (
                  <div>
                    <p className="text-sm text-muted-foreground">Data do Consentimento</p>
                    <p className="font-medium">
                      {format(new Date(patient.lgpdConsentAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Anamnese Tab */}
        <TabsContent value="anamnesis" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Anamnese</CardTitle>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-2">Queixa Principal</h4>
                <p className="text-muted-foreground">{anamnesis.mainComplaint}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Histórico da Doença</h4>
                <p className="text-muted-foreground">{anamnesis.diseaseHistory}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Histórico Familiar</h4>
                <p className="text-muted-foreground">{anamnesis.familyHistory}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Histórico Pessoal</h4>
                <p className="text-muted-foreground">{anamnesis.personalHistory}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Histórico Médico</h4>
                <p className="text-muted-foreground">{anamnesis.medicalHistory}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Medicamentos em Uso</h4>
                <p className="text-muted-foreground">{anamnesis.medications}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Tratamentos Anteriores</h4>
                <p className="text-muted-foreground">{anamnesis.previousTreatments}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Expectativas</h4>
                <p className="text-muted-foreground">{anamnesis.expectations}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Observações Gerais</h4>
                <p className="text-muted-foreground">{anamnesis.notes}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sessions Tab */}
        <TabsContent value="sessions" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Histórico de Sessões</CardTitle>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Nova Sessão
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-2">
                  {mockSessions.map((session) => (
                    <div 
                      key={session.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="font-semibold text-primary">#{session.number}</span>
                        </div>
                        <div>
                          <p className="font-medium">Sessão {session.number}</p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(session.date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={session.paid ? 'default' : 'destructive'}>
                          {session.paid ? 'Pago' : 'Pendente'}
                        </Badge>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notes Tab */}
        <TabsContent value="notes" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <CardTitle className="text-lg">Anotações</CardTitle>
                {isNotesLocked && (
                  <Lock className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setIsNotesLocked(!isNotesLocked)}
                >
                  {isNotesLocked ? (
                    <>
                      <Unlock className="h-4 w-4 mr-2" />
                      Desbloquear
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4 mr-2" />
                      Bloquear
                    </>
                  )}
                </Button>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Nota
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isNotesLocked ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Lock className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Notas Criptografadas</h3>
                  <p className="text-muted-foreground mb-4 max-w-md">
                    As notas clínicas são protegidas por criptografia de ponta a ponta.
                    Clique em "Desbloquear" para visualizar.
                  </p>
                  <Button onClick={() => setIsNotesLocked(false)}>
                    <Unlock className="h-4 w-4 mr-2" />
                    Desbloquear Notas
                  </Button>
                </div>
              ) : (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-2">
                    {mockNotes.map((note) => (
                      <div 
                        key={note.id}
                        className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 cursor-pointer"
                      >
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            'w-10 h-10 rounded-lg flex items-center justify-center',
                            note.type === 'clinical' ? 'bg-primary/10' : 'bg-amber-100 dark:bg-amber-900/30'
                          )}>
                            {note.type === 'clinical' ? (
                              <Lock className="h-5 w-5 text-primary" />
                            ) : (
                              <FileText className="h-5 w-5 text-amber-600" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{note.title}</p>
                              <Badge variant="outline" className="text-xs">
                                {note.type === 'clinical' ? 'Clínica' : 'Administrativa'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(note.date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                            </p>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Attachments Tab */}
        <TabsContent value="attachments" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Documentos e Anexos</CardTitle>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Upload
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-2">
                  {mockAttachments.map((attachment) => (
                    <div 
                      key={attachment.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                          <FileText className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="font-medium">{attachment.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {(attachment.size / 1024).toFixed(0)} KB • {format(new Date(attachment.uploadedAt), "dd/MM/yyyy", { locale: ptBR })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
