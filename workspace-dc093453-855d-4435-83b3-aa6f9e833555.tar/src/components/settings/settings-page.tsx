'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  User,
  Bell,
  Shield,
  Clock,
  Palette,
  Mail,
  Phone,
  Save,
  Key,
  Smartphone,
  Globe,
  Database,
  Download,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

export function SettingsPage() {
  const [loading, setLoading] = useState(false);

  // Profile settings
  const [name, setName] = useState('Dra. Maria Silva');
  const [email, setEmail] = useState('maria.silva@crp06.gov.br');
  const [phone, setPhone] = useState('(11) 99999-9999');
  const [crp, setCrp] = useState('CRP 06/123456');
  const [specialty, setSpecialty] = useState('Psicanálise');

  // Session settings
  const [sessionDuration, setSessionDuration] = useState('50');
  const [sessionFee, setSessionFee] = useState('200');
  const [workingHoursStart, setWorkingHoursStart] = useState('08:00');
  const [workingHoursEnd, setWorkingHoursEnd] = useState('19:00');
  const [workingDays, setWorkingDays] = useState<string[]>(['1', '2', '3', '4', '5']);

  // Notification settings
  const [emailReminders, setEmailReminders] = useState(true);
  const [whatsappReminders, setWhatsappReminders] = useState(true);
  const [reminderTime, setReminderTime] = useState('24');

  // Privacy settings
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [biometricUnlock, setBiometricUnlock] = useState(false);
  const [autoLockNotes, setAutoLockNotes] = useState(true);
  const [lockTimeout, setLockTimeout] = useState('5');

  const handleSave = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast.success('Configurações salvas com sucesso!');
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Configurações</h1>
          <p className="text-muted-foreground">Personalize o sistema de acordo com suas preferências</p>
        </div>
        <Button onClick={handleSave} disabled={loading}>
          <Save className="h-4 w-4 mr-2" />
          {loading ? 'Salvando...' : 'Salvar Alterações'}
        </Button>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="sessions">Sessões</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="privacy">Privacidade</TabsTrigger>
          <TabsTrigger value="data">Dados</TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Dados Pessoais
              </CardTitle>
              <CardDescription>
                Informações do seu perfil profissional
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input 
                    id="name" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="crp">Registro CRP</Label>
                  <Input 
                    id="crp" 
                    value={crp} 
                    onChange={(e) => setCrp(e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input 
                    id="email" 
                    type="email"
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <Input 
                    id="phone" 
                    value={phone} 
                    onChange={(e) => setPhone(e.target.value)} 
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="specialty">Especialidade</Label>
                  <Input 
                    id="specialty" 
                    value={specialty} 
                    onChange={(e) => setSpecialty(e.target.value)} 
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Aparência
              </CardTitle>
              <CardDescription>
                Personalize a interface do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Tema</p>
                  <p className="text-sm text-muted-foreground">
                    Escolha entre modo claro e escuro
                  </p>
                </div>
                <Select defaultValue="system">
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Claro</SelectItem>
                    <SelectItem value="dark">Escuro</SelectItem>
                    <SelectItem value="system">Sistema</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Session Settings */}
        <TabsContent value="sessions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Configurações de Sessão
              </CardTitle>
              <CardDescription>
                Defina os padrões para suas sessões
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Duração Padrão</Label>
                  <Select value={sessionDuration} onValueChange={setSessionDuration}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 minutos</SelectItem>
                      <SelectItem value="45">45 minutos</SelectItem>
                      <SelectItem value="50">50 minutos</SelectItem>
                      <SelectItem value="60">60 minutos</SelectItem>
                      <SelectItem value="90">90 minutos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Valor Padrão (R$)</Label>
                  <Input 
                    type="number"
                    value={sessionFee} 
                    onChange={(e) => setSessionFee(e.target.value)} 
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Horário de Funcionamento</Label>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground">Início</Label>
                    <Input 
                      type="time"
                      value={workingHoursStart} 
                      onChange={(e) => setWorkingHoursStart(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground">Término</Label>
                    <Input 
                      type="time"
                      value={workingHoursEnd} 
                      onChange={(e) => setWorkingHoursEnd(e.target.value)} 
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Dias de Atendimento</Label>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: '1', label: 'Seg' },
                    { value: '2', label: 'Ter' },
                    { value: '3', label: 'Qua' },
                    { value: '4', label: 'Qui' },
                    { value: '5', label: 'Sex' },
                    { value: '6', label: 'Sáb' },
                    { value: '0', label: 'Dom' },
                  ].map((day) => (
                    <Button
                      key={day.value}
                      variant={workingDays.includes(day.value) ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => {
                        if (workingDays.includes(day.value)) {
                          setWorkingDays(workingDays.filter(d => d !== day.value));
                        } else {
                          setWorkingDays([...workingDays, day.value]);
                        }
                      }}
                    >
                      {day.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Lembretes
              </CardTitle>
              <CardDescription>
                Configure os lembretes automáticos para reduzir faltas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Lembretes por E-mail</p>
                    <p className="text-sm text-muted-foreground">
                      Enviar lembretes automáticos por e-mail
                    </p>
                  </div>
                </div>
                <Switch
                  checked={emailReminders}
                  onCheckedChange={setEmailReminders}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Lembretes por WhatsApp</p>
                    <p className="text-sm text-muted-foreground">
                      Enviar lembretes automáticos via WhatsApp
                    </p>
                  </div>
                </div>
                <Switch
                  checked={whatsappReminders}
                  onCheckedChange={setWhatsappReminders}
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Enviar lembrete</Label>
                <Select value={reminderTime} onValueChange={setReminderTime}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hora antes</SelectItem>
                    <SelectItem value="2">2 horas antes</SelectItem>
                    <SelectItem value="4">4 horas antes</SelectItem>
                    <SelectItem value="24">24 horas antes</SelectItem>
                    <SelectItem value="48">48 horas antes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Segurança
              </CardTitle>
              <CardDescription>
                Configure a segurança do seu sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Key className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Autenticação em Dois Fatores</p>
                    <p className="text-sm text-muted-foreground">
                      Adicione uma camada extra de segurança
                    </p>
                  </div>
                </div>
                <Switch
                  checked={twoFactorEnabled}
                  onCheckedChange={setTwoFactorEnabled}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Smartphone className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Desbloqueio Biométrico</p>
                    <p className="text-sm text-muted-foreground">
                      Usar biometria para acessar notas clínicas
                    </p>
                  </div>
                </div>
                <Switch
                  checked={biometricUnlock}
                  onCheckedChange={setBiometricUnlock}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Bloqueio Automático de Notas</p>
                  <p className="text-sm text-muted-foreground">
                    Bloquear notas clínicas após inatividade
                  </p>
                </div>
                <Switch
                  checked={autoLockNotes}
                  onCheckedChange={setAutoLockNotes}
                />
              </div>

              {autoLockNotes && (
                <div className="space-y-2">
                  <Label>Tempo para bloqueio automático</Label>
                  <Select value={lockTimeout} onValueChange={setLockTimeout}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 minuto</SelectItem>
                      <SelectItem value="5">5 minutos</SelectItem>
                      <SelectItem value="15">15 minutos</SelectItem>
                      <SelectItem value="30">30 minutos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>LGPD - Lei Geral de Proteção de Dados</CardTitle>
              <CardDescription>
                Gerenciamento de dados pessoais conforme a LGPD
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-sm">
                  Este sistema está em conformidade com a LGPD (Lei nº 13.709/2018). 
                  Todos os dados dos pacientes são protegidos por criptografia de ponta a ponta.
                </p>
              </div>
              <div className="grid gap-2">
                <Button variant="outline" className="justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar meus dados
                </Button>
                <Button variant="outline" className="justify-start">
                  <Globe className="h-4 w-4 mr-2" />
                  Ver política de privacidade
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Settings */}
        <TabsContent value="data" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Backup e Dados
              </CardTitle>
              <CardDescription>
                Gerencie seus dados e backups
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <p className="font-medium">Backup automático ativo</p>
                </div>
                <p className="text-sm text-green-600 dark:text-green-500 mt-1">
                  Último backup: há 2 horas
                </p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Frequência de Backup</Label>
                <Select defaultValue="daily">
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">A cada hora</SelectItem>
                    <SelectItem value="daily">Diariamente</SelectItem>
                    <SelectItem value="weekly">Semanalmente</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="grid gap-2">
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Fazer backup agora
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Restaurar backup
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <AlertCircle className="h-5 w-5" />
                Zona de Perigo
              </CardTitle>
              <CardDescription>
                Ações irreversíveis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Excluir todos os dados</p>
                  <p className="text-sm text-muted-foreground">
                    Esta ação não pode ser desfeita
                  </p>
                </div>
                <Button variant="destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Excluir
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
