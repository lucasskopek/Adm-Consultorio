'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Users, 
  CalendarDays, 
  DollarSign, 
  TrendingUp,
  TrendingDown,
  Clock,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon: React.ElementType;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: 'default' | 'success' | 'warning' | 'destructive';
}

function StatCard({ title, value, description, icon: Icon, trend, variant = 'default' }: StatCardProps) {
  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn(
          'p-2 rounded-lg',
          variant === 'success' && 'bg-green-100 dark:bg-green-900/30',
          variant === 'warning' && 'bg-amber-100 dark:bg-amber-900/30',
          variant === 'destructive' && 'bg-red-100 dark:bg-red-900/30',
          variant === 'default' && 'bg-primary/10'
        )}>
          <Icon className={cn(
            'h-4 w-4',
            variant === 'success' && 'text-green-600 dark:text-green-400',
            variant === 'warning' && 'text-amber-600 dark:text-amber-400',
            variant === 'destructive' && 'text-red-600 dark:text-red-400',
            variant === 'default' && 'text-primary'
          )} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {(description || trend) && (
          <div className="flex items-center gap-2 mt-1">
            {trend && (
              <span className={cn(
                'flex items-center text-xs',
                trend.isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              )}>
                {trend.isPositive ? (
                  <TrendingUp className="h-3 w-3 mr-1" />
                ) : (
                  <TrendingDown className="h-3 w-3 mr-1" />
                )}
                {trend.value}%
              </span>
            )}
            {description && (
              <p className="text-xs text-muted-foreground">{description}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function StatsCards() {
  const stats = [
    {
      title: 'Pacientes Ativos',
      value: '47',
      description: 'vs. mês anterior',
      icon: Users,
      trend: { value: 12, isPositive: true },
      variant: 'default' as const,
    },
    {
      title: 'Sessões Hoje',
      value: '8',
      description: '2 confirmadas, 1 pendente',
      icon: CalendarDays,
      variant: 'success' as const,
    },
    {
      title: 'Faturamento Mensal',
      value: 'R$ 15.840',
      description: 'vs. mês anterior',
      icon: DollarSign,
      trend: { value: 8, isPositive: true },
      variant: 'default' as const,
    },
    {
      title: 'Sessões Não Pagas',
      value: '5',
      description: 'Total: R$ 1.250',
      icon: AlertCircle,
      variant: 'warning' as const,
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <StatCard key={stat.title} {...stat} />
      ))}
    </div>
  );
}
