'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  MoreVertical,
  Eye,
  FileText,
  Calendar
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Patient {
  id: string;
  name: string;
  initials: string;
  lastSession: string;
  totalSessions: number;
  status: 'active' | 'inactive' | 'waiting_list';
}

const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'Ana Silva',
    initials: 'AS',
    lastSession: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 45,
    status: 'active',
  },
  {
    id: '2',
    name: 'Carlos Mendes',
    initials: 'CM',
    lastSession: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 23,
    status: 'active',
  },
  {
    id: '3',
    name: 'Beatriz Costa',
    initials: 'BC',
    lastSession: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 67,
    status: 'active',
  },
  {
    id: '4',
    name: 'Daniel Oliveira',
    initials: 'DO',
    lastSession: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 12,
    status: 'inactive',
  },
  {
    id: '5',
    name: 'Elena Santos',
    initials: 'ES',
    lastSession: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    totalSessions: 89,
    status: 'active',
  },
  {
    id: '6',
    name: 'Fernando Lima',
    initials: 'FL',
    lastSession: new Date().toISOString(),
    totalSessions: 1,
    status: 'waiting_list',
  },
];

const statusConfig = {
  active: { label: 'Ativo', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
  inactive: { label: 'Inativo', color: 'bg-muted text-muted-foreground' },
  waiting_list: { label: 'Lista de Espera', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' },
};

interface RecentPatientsProps {
  onPatientClick?: (patientId: string) => void;
}

function PatientItem({ patient, onClick }: { patient: Patient; onClick?: () => void }) {
  const status = statusConfig[patient.status];
  const lastSessionLabel = formatDistanceToNow(new Date(patient.lastSession), {
    addSuffix: true,
    locale: ptBR,
  });

  return (
    <div 
      className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors group cursor-pointer" 
      onClick={onClick}
    >
      {/* Avatar */}
      <Avatar className="h-10 w-10">
        <AvatarFallback className="bg-primary/10 text-primary font-medium">
          {patient.initials}
        </AvatarFallback>
      </Avatar>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{patient.name}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <FileText className="h-3 w-3" />
          <span>{patient.totalSessions} sessões</span>
        </div>
      </div>

      {/* Last Session */}
      <div className="hidden sm:block text-right">
        <p className="text-xs text-muted-foreground">Última sessão</p>
        <p className="text-xs font-medium capitalize">{lastSessionLabel}</p>
      </div>

      {/* Status */}
      <Badge variant="secondary" className={cn('text-xs', status.color)}>
        {status.label}
      </Badge>

      {/* Actions */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <MoreVertical className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>
            <Eye className="h-4 w-4 mr-2" />
            Ver Prontuário
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Calendar className="h-4 w-4 mr-2" />
            Agendar Sessão
          </DropdownMenuItem>
          <DropdownMenuItem>
            <FileText className="h-4 w-4 mr-2" />
            Nova Anotação
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export function RecentPatients({ onPatientClick }: RecentPatientsProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg font-semibold">Pacientes Recentes</CardTitle>
          <p className="text-sm text-muted-foreground">Últimas atividades</p>
        </div>
        <Button variant="outline" size="sm">
          Ver Todos
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[320px] pr-4">
          <div className="space-y-1">
            {mockPatients.map((patient) => (
              <PatientItem 
                key={patient.id} 
                patient={patient} 
                onClick={() => onPatientClick?.(patient.id)}
              />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
