'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Clock, 
  Video, 
  Phone, 
  MapPin,
  MoreVertical,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { format, isToday, isTomorrow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Session {
  id: string;
  patientName: string;
  patientInitials: string;
  time: string;
  duration: number;
  type: 'presencial' | 'online' | 'telefone';
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled' | 'no_show';
}

const mockSessions: Session[] = [
  {
    id: '1',
    patientName: 'Ana Silva',
    patientInitials: 'AS',
    time: '09:00',
    duration: 50,
    type: 'presencial',
    status: 'confirmed',
  },
  {
    id: '2',
    patientName: 'Carlos Mendes',
    patientInitials: 'CM',
    time: '10:00',
    duration: 50,
    type: 'online',
    status: 'pending',
  },
  {
    id: '3',
    patientName: 'Beatriz Costa',
    patientInitials: 'BC',
    time: '11:00',
    duration: 50,
    type: 'presencial',
    status: 'confirmed',
  },
  {
    id: '4',
    patientName: 'Daniel Oliveira',
    patientInitials: 'DO',
    time: '14:00',
    duration: 50,
    type: 'telefone',
    status: 'pending',
  },
  {
    id: '5',
    patientName: 'Elena Santos',
    patientInitials: 'ES',
    time: '15:00',
    duration: 50,
    type: 'presencial',
    status: 'confirmed',
  },
];

const statusConfig = {
  confirmed: { label: 'Confirmada', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
  pending: { label: 'Pendente', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' },
  completed: { label: 'Concluída', color: 'bg-muted text-muted-foreground' },
  cancelled: { label: 'Cancelada', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
  no_show: { label: 'Não compareceu', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
};

const typeIcons = {
  presencial: MapPin,
  online: Video,
  telefone: Phone,
};

function SessionItem({ session }: { session: Session }) {
  const TypeIcon = typeIcons[session.type];
  const status = statusConfig[session.status];

  return (
    <div className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors group">
      {/* Time */}
      <div className="w-14 text-center">
        <span className="text-sm font-medium">{session.time}</span>
        <p className="text-xs text-muted-foreground">{session.duration}min</p>
      </div>

      {/* Avatar */}
      <Avatar className="h-10 w-10">
        <AvatarFallback className="bg-primary/10 text-primary font-medium">
          {session.patientInitials}
        </AvatarFallback>
      </Avatar>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{session.patientName}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <TypeIcon className="h-3 w-3" />
          <span className="capitalize">{session.type}</span>
        </div>
      </div>

      {/* Status */}
      <Badge variant="secondary" className={cn('text-xs', status.color)}>
        {status.label}
      </Badge>

      {/* Actions */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <MoreVertical className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>
            <CheckCircle className="h-4 w-4 mr-2" />
            Iniciar Sessão
          </DropdownMenuItem>
          <DropdownMenuItem>
            <AlertCircle className="h-4 w-4 mr-2" />
            Remarcar
          </DropdownMenuItem>
          <DropdownMenuItem className="text-destructive">
            <XCircle className="h-4 w-4 mr-2" />
            Cancelar
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export function UpcomingSessions() {
  const today = new Date();
  const dateLabel = isToday(today) 
    ? 'Hoje' 
    : isTomorrow(today) 
      ? 'Amanhã' 
      : format(today, "EEEE, d 'de' MMMM", { locale: ptBR });

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg font-semibold">Próximas Sessões</CardTitle>
          <p className="text-sm text-muted-foreground capitalize">{dateLabel}</p>
        </div>
        <Button variant="outline" size="sm">
          Ver Agenda
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[320px] pr-4">
          <div className="space-y-1">
            {mockSessions.map((session) => (
              <SessionItem key={session.id} session={session} />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
