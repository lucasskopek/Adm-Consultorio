'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Bar, BarChart, XAxis, YAxis, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp, DollarSign } from 'lucide-react';

const monthlyData = [
  { month: 'Jan', faturamento: 12400, sessoes: 62 },
  { month: 'Fev', faturamento: 13800, sessoes: 69 },
  { month: 'Mar', faturamento: 14200, sessoes: 71 },
  { month: 'Abr', faturamento: 15600, sessoes: 78 },
  { month: 'Mai', faturamento: 13200, sessoes: 66 },
  { month: 'Jun', faturamento: 15840, sessoes: 79 },
];

const chartConfig = {
  faturamento: {
    label: "Faturamento",
    color: "hsl(var(--primary))",
  },
} satisfies ChartConfig;

export function FinanceChart() {
  const total = monthlyData.reduce((acc, curr) => acc + curr.faturamento, 0);
  const average = total / monthlyData.length;

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg font-semibold">Faturamento</CardTitle>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-bold">
              R$ {total.toLocaleString('pt-BR')}
            </span>
            <span className="text-xs text-muted-foreground">últimos 6 meses</span>
          </div>
        </div>
        <Select defaultValue="6months">
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="30days">30 dias</SelectItem>
            <SelectItem value="3months">3 meses</SelectItem>
            <SelectItem value="6months">6 meses</SelectItem>
            <SelectItem value="12months">12 meses</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[240px] w-full">
          <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="faturamentoGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="month" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
              tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
            />
            <ChartTooltip 
              content={<ChartTooltipContent />}
              formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Faturamento']}
            />
            <Area
              type="monotone"
              dataKey="faturamento"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              fill="url(#faturamentoGradient)"
            />
          </AreaChart>
        </ChartContainer>
        
        {/* Summary */}
        <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t">
          <div>
            <p className="text-sm text-muted-foreground">Média Mensal</p>
            <p className="text-lg font-semibold">
              R$ {average.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Tendência</p>
            <div className="flex items-center gap-1 text-green-600 dark:text-green-400">
              <TrendingUp className="h-4 w-4" />
              <span className="text-lg font-semibold">+8.2%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
