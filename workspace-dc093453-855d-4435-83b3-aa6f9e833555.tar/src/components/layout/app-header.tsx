'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Plus,
  Search,
  Bell,
  User,
  CalendarPlus,
  UserPlus,
  ChevronDown
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useUIStore, useAppStore } from '@/lib/store/app-store';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function AppHeader() {
  const { setNewSessionModalOpen, setNewPatientModalOpen } = useUIStore();
  const { searchQuery, setSearchQuery } = useAppStore();
  const [notifications] = useState(3);
  const today = new Date();

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-16 items-center px-4 md:px-6 gap-4">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar pacientes, sessões..."
              className="pl-8 w-full bg-muted/50 border-0 focus-visible:ring-1"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Date Display */}
        <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
          <CalendarPlus className="h-4 w-4" />
          <span>
            {format(today, "EEEE, d 'de' MMMM", { locale: ptBR })}
          </span>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            {notifications > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]"
              >
                {notifications}
              </Badge>
            )}
          </Button>

          {/* Quick Add Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 gap-1">
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">Nova Sessão</span>
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => setNewSessionModalOpen(true)}>
                <CalendarPlus className="h-4 w-4 mr-2" />
                Nova Sessão
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setNewPatientModalOpen(true)}>
                <UserPlus className="h-4 w-4 mr-2" />
                Novo Paciente
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="h-4 w-4 mr-2" />
                Perfil
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
