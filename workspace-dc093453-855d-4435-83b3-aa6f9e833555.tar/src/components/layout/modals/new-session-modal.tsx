'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  CalendarIcon, 
  Clock,
  Video,
  Phone,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { useUIStore } from '@/lib/store/app-store';
import { toast } from 'sonner';

const patients = [
  { id: '1', name: 'Ana Silva' },
  { id: '2', name: 'Carlos Mendes' },
  { id: '3', name: 'Beatriz Costa' },
  { id: '4', name: 'Daniel Oliveira' },
  { id: '5', name: 'Elena Santos' },
];

const timeSlots = [
  '08:00', '09:00', '10:00', '11:00', '12:00',
  '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'
];

const recurrenceOptions = [
  { value: 'none', label: 'Não repetir' },
  { value: 'weekly', label: 'Toda semana' },
  { value: 'biweekly', label: 'A cada 2 semanas' },
  { value: 'monthly', label: 'Todo mês' },
];

export function NewSessionModal() {
  const { newSessionModalOpen, setNewSessionModalOpen } = useUIStore();
  const [selectedPatient, setSelectedPatient] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState('');
  const [duration, setDuration] = useState('50');
  const [sessionType, setSessionType] = useState<'presencial' | 'online' | 'telefone'>('presencial');
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurrenceType, setRecurrenceType] = useState('weekly');
  const [fee, setFee] = useState('200');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!selectedPatient || !selectedDate || !selectedTime) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.success('Sessão agendada com sucesso!');
    setNewSessionModalOpen(false);
    setLoading(false);
    
    // Reset form
    setSelectedPatient('');
    setSelectedDate(undefined);
    setSelectedTime('');
    setNotes('');
  };

  return (
    <Dialog open={newSessionModalOpen} onOpenChange={setNewSessionModalOpen}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Nova Sessão</DialogTitle>
          <DialogDescription>
            Agende uma nova sessão com um paciente
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          {/* Patient Select */}
          <div className="grid gap-2">
            <Label htmlFor="patient">Paciente *</Label>
            <Select value={selectedPatient} onValueChange={setSelectedPatient}>
              <SelectTrigger id="patient">
                <SelectValue placeholder="Selecione um paciente" />
              </SelectTrigger>
              <SelectContent>
                {patients.map((patient) => (
                  <SelectItem key={patient.id} value={patient.id}>
                    {patient.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Data *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'justify-start text-left font-normal',
                      !selectedDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, 'PPP', { locale: ptBR }) : 'Selecionar'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    initialFocus
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label>Horário *</Label>
              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger>
                  <Clock className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Horário" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Duration and Fee */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Duração (min)</Label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutos</SelectItem>
                  <SelectItem value="50">50 minutos</SelectItem>
                  <SelectItem value="60">60 minutos</SelectItem>
                  <SelectItem value="90">90 minutos</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label>Valor (R$)</Label>
              <Input
                type="number"
                value={fee}
                onChange={(e) => setFee(e.target.value)}
                placeholder="200,00"
              />
            </div>
          </div>

          {/* Session Type */}
          <div className="grid gap-2">
            <Label>Tipo de Sessão</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={sessionType === 'presencial' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setSessionType('presencial')}
              >
                <MapPin className="mr-2 h-4 w-4" />
                Presencial
              </Button>
              <Button
                type="button"
                variant={sessionType === 'online' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setSessionType('online')}
              >
                <Video className="mr-2 h-4 w-4" />
                Online
              </Button>
              <Button
                type="button"
                variant={sessionType === 'telefone' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setSessionType('telefone')}
              >
                <Phone className="mr-2 h-4 w-4" />
                Telefone
              </Button>
            </div>
          </div>

          {/* Recurrence */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Sessão Recorrente</p>
                <p className="text-xs text-muted-foreground">
                  Repetir automaticamente
                </p>
              </div>
            </div>
            <Switch
              checked={isRecurring}
              onCheckedChange={setIsRecurring}
            />
          </div>

          {isRecurring && (
            <div className="grid gap-2">
              <Label>Frequência</Label>
              <Select value={recurrenceType} onValueChange={setRecurrenceType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {recurrenceOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Notes */}
          <div className="grid gap-2">
            <Label htmlFor="notes">Observações</Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notas adicionais..."
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => setNewSessionModalOpen(false)}
          >
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? 'Agendando...' : 'Agendar Sessão'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
