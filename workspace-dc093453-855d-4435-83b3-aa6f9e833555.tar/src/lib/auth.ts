// Authentication configuration for Clínica Psi
import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { db } from '@/lib/db';
import { createHash } from 'crypto';

// Password hashing using SHA-256
export function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export const authOptions: NextAuthOptions = {
  // No adapter for credentials provider - we handle user lookup manually
  providers: [
    CredentialsProvider({
      id: 'credentials',
      name: 'credentials',
      type: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email', placeholder: 'email@example.com' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        console.log('🔐 [Auth] Authorize called');
        console.log('   Email:', credentials?.email);
        
        if (!credentials?.email || !credentials?.password) {
          console.log('❌ [Auth] Missing email or password');
          return null;
        }

        const email = credentials.email.toLowerCase().trim();
        const password = credentials.password;

        // Find user
        const user = await db.user.findUnique({
          where: { email }
        });

        if (!user) {
          console.log('❌ [Auth] User not found:', email);
          return null;
        }

        if (!user.passwordHash) {
          console.log('❌ [Auth] User has no password hash');
          return null;
        }

        // Verify password
        const passwordHash = hashPassword(password);
        
        if (passwordHash !== user.passwordHash) {
          console.log('❌ [Auth] Invalid password');
          console.log('   Expected:', user.passwordHash.substring(0, 16) + '...');
          console.log('   Got:     ', passwordHash.substring(0, 16) + '...');
          return null;
        }

        console.log('✅ [Auth] Authentication successful for:', email);

        // Return user object
        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role || 'therapist',
          crp: user.crp,
          specialty: user.specialty,
          avatar: user.avatar
        };
      }
    })
  ],
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  pages: {
    signIn: '/login',
    error: '/login',
  },
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      // Initial sign in
      if (user) {
        token.id = user.id;
        token.email = user.email;
        token.name = user.name;
        token.role = user.role;
        token.crp = user.crp;
        token.specialty = user.specialty;
        token.avatar = user.avatar;
      }
      
      // Update session
      if (trigger === 'update' && session) {
        token = { ...token, ...session };
      }
      
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.user.id = token.id as string;
        session.user.email = token.email as string;
        session.user.name = token.name as string;
        session.user.role = token.role as string;
        session.user.crp = token.crp as string | null;
        session.user.specialty = token.specialty as string | null;
        session.user.avatar = token.avatar as string | null;
      }
      return session;
    },
    async redirect({ url, baseUrl }) {
      // Allows relative callback URLs
      if (url.startsWith('/')) return `${baseUrl}${url}`;
      // Allows callback URLs on the same origin
      if (new URL(url).origin === baseUrl) return url;
      return baseUrl;
    }
  },
  events: {
    async signIn({ user, account, profile, isNewUser }) {
      console.log('✅ [Auth] signIn event:', user.email);
      
      // Update last login
      if (user.id) {
        try {
          await db.user.update({
            where: { id: user.id },
            data: { lastLoginAt: new Date() }
          });
        } catch (e) {
          console.log('[Auth] Warning: Could not update lastLoginAt');
        }
      }
    },
    async signOut({ token }) {
      console.log('👋 [Auth] signOut event');
    }
  },
  debug: true,
  secret: process.env.NEXTAUTH_SECRET,
};
