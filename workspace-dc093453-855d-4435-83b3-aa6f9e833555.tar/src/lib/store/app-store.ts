import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// ===========================================
// TYPES
// ===========================================
export interface Patient {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  birthDate: string | null;
  gender: string | null;
  status: string;
  createdAt: string;
}

export interface Session {
  id: string;
  patientId: string;
  patientName: string;
  scheduledAt: string;
  duration: number;
  status: string;
  fee: number | null;
  paid: boolean;
}

export interface Appointment {
  id: string;
  patientId: string | null;
  patientName: string;
  title: string;
  startTime: string;
  endTime: string;
  status: string;
  isRecurring: boolean;
}

// ===========================================
// UI STATE STORE
// ===========================================
interface UIState {
  // Sidebar
  sidebarOpen: boolean;
  sidebarCollapsed: boolean;
  
  // Modals
  newSessionModalOpen: boolean;
  newPatientModalOpen: boolean;
  
  // View preferences
  calendarView: 'day' | 'week' | 'month';
  
  // Actions
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
  setNewSessionModalOpen: (open: boolean) => void;
  setNewPatientModalOpen: (open: boolean) => void;
  setCalendarView: (view: 'day' | 'week' | 'month') => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      sidebarCollapsed: false,
      newSessionModalOpen: false,
      newPatientModalOpen: false,
      calendarView: 'week',
      
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setNewSessionModalOpen: (open) => set({ newSessionModalOpen: open }),
      setNewPatientModalOpen: (open) => set({ newPatientModalOpen: open }),
      setCalendarView: (view) => set({ calendarView: view }),
    }),
    {
      name: 'clinic-ui-storage',
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed,
        calendarView: state.calendarView,
      }),
    }
  )
);

// ===========================================
// APP STATE STORE
// ===========================================
interface AppState {
  // Current selections
  selectedPatientId: string | null;
  selectedSessionId: string | null;
  selectedDate: string;
  
  // Search
  searchQuery: string;
  
  // Actions
  setSelectedPatientId: (id: string | null) => void;
  setSelectedSessionId: (id: string | null) => void;
  setSelectedDate: (date: string) => void;
  setSearchQuery: (query: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      selectedPatientId: null,
      selectedSessionId: null,
      selectedDate: new Date().toISOString(),
      searchQuery: '',
      
      setSelectedPatientId: (id) => set({ selectedPatientId: id }),
      setSelectedSessionId: (id) => set({ selectedSessionId: id }),
      setSelectedDate: (date) => set({ selectedDate: date }),
      setSearchQuery: (query) => set({ searchQuery: query }),
    }),
    {
      name: 'clinic-app-storage',
    }
  )
);
