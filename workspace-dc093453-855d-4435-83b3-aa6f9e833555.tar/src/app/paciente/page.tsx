'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Brain,
  Calendar,
  Clock,
  FileText,
  Download,
  User,
  Bell,
  LogOut
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

// Mock patient data
const mockPatientData = {
  name: 'Ana Silva',
  email: 'ana.silva@email.com',
  phone: '(11) 98765-4321',
  therapist: {
    name: 'Dra. Maria Silva',
    crp: 'CRP 06/123456',
  },
};

const mockUpcomingSessions = [
  {
    id: '1',
    date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    time: '09:00',
    duration: 50,
    type: 'presencial',
    status: 'confirmed',
  },
  {
    id: '2',
    date: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000).toISOString(),
    time: '09:00',
    duration: 50,
    type: 'presencial',
    status: 'scheduled',
  },
];

const mockPastSessions = [
  {
    id: '3',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    time: '09:00',
    duration: 50,
    type: 'presencial',
    status: 'completed',
  },
  {
    id: '4',
    date: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(),
    time: '09:00',
    duration: 50,
    type: 'presencial',
    status: 'completed',
  },
];

const mockPayments = [
  {
    id: '1',
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    amount: 400,
    sessions: 2,
    status: 'paid',
    receiptUrl: '#',
  },
  {
    id: '2',
    date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
    amount: 400,
    sessions: 2,
    status: 'paid',
    receiptUrl: '#',
  },
];

export default function PatientPortalPage() {
  const [activeTab, setActiveTab] = useState('sessions');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-semibold">Clínica Psi</h1>
              <p className="text-xs text-muted-foreground">Portal do Paciente</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => toast.success('Logout realizado')}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* User Info Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-8 w-8 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-semibold">{mockPatientData.name}</h2>
                <p className="text-muted-foreground">{mockPatientData.email}</p>
                <p className="text-sm text-muted-foreground">
                  Psicanalista: {mockPatientData.therapist.name} ({mockPatientData.therapist.crp})
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="sessions">
              <Calendar className="h-4 w-4 mr-2" />
              Sessões
            </TabsTrigger>
            <TabsTrigger value="payments">
              <FileText className="h-4 w-4 mr-2" />
              Financeiro
            </TabsTrigger>
            <TabsTrigger value="documents">
              <Download className="h-4 w-4 mr-2" />
              Documentos
            </TabsTrigger>
          </TabsList>

          {/* Sessions Tab */}
          <TabsContent value="sessions" className="space-y-4 mt-4">
            {/* Upcoming Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Próximas Sessões</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockUpcomingSessions.map((session) => (
                    <div 
                      key={session.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">
                            {format(new Date(session.date), "EEEE, d 'de' MMMM", { locale: ptBR })}
                          </p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>{session.time} ({session.duration} min)</span>
                          </div>
                        </div>
                      </div>
                      <Badge 
                        variant={session.status === 'confirmed' ? 'default' : 'secondary'}
                      >
                        {session.status === 'confirmed' ? 'Confirmada' : 'Agendada'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Past Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Histórico de Sessões</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-2">
                    {mockPastSessions.map((session) => (
                      <div 
                        key={session.id}
                        className="flex items-center justify-between p-3 rounded-lg border"
                      >
                        <div>
                          <p className="font-medium">
                            {format(new Date(session.date), "dd/MM/yyyy")}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {session.time} • {session.duration} min
                          </p>
                        </div>
                        <Badge variant="secondary">Concluída</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Histórico de Pagamentos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockPayments.map((payment) => (
                    <div 
                      key={payment.id}
                      className="flex items-center justify-between p-4 rounded-lg border"
                    >
                      <div>
                        <p className="font-medium">
                          R$ {payment.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {payment.sessions} sessão(ões) • {format(new Date(payment.date), 'dd/MM/yyyy')}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          Pago
                        </Badge>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Recibo
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Documentos e Relatórios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Nenhum documento disponível</p>
                  <p className="text-sm">Seus documentos aparecerão aqui</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-8">
        <div className="container max-w-4xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Clínica Psi - Todos os direitos reservados</p>
        </div>
      </footer>
    </div>
  );
}
