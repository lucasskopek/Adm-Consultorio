'use client';

import { useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { AuthGuard } from '@/components/auth/auth-guard';
import { AppSidebar } from '@/components/layout/app-sidebar';
import { AppHeader } from '@/components/layout/app-header';
import { NewSessionModal } from '@/components/layout/modals/new-session-modal';
import { NewPatientModal } from '@/components/layout/modals/new-patient-modal';
import { StatsCards } from '@/components/dashboard/stats-cards';
import { UpcomingSessions } from '@/components/dashboard/upcoming-sessions';
import { RecentPatients } from '@/components/dashboard/recent-patients';
import { FinanceChart } from '@/components/dashboard/finance-chart';
import { PatientList } from '@/components/patients/patient-list';
import { PatientDetail } from '@/components/patients/patient-detail';
import { CalendarView } from '@/components/appointments/calendar-view';
import { FinanceOverview } from '@/components/finance/finance-overview';
import { ReportsDashboard } from '@/components/finance/reports-dashboard';
import { ReceiptGenerator } from '@/components/finance/receipt-generator';
import { SettingsPage } from '@/components/settings/settings-page';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Receipt, BarChart3 } from 'lucide-react';

type TabType = 'dashboard' | 'patients' | 'calendar' | 'finance' | 'settings' | 'notifications';

function HomeContent() {
  const searchParams = useSearchParams();
  const tab = (searchParams.get('tab') as TabType) || 'dashboard';
  
  // Patient detail state
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  
  // Receipt modal state
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  
  // Finance sub-tab
  const [financeTab, setFinanceTab] = useState('overview');

  const handlePatientClick = (patientId: string) => {
    setSelectedPatientId(patientId);
  };

  const handleBackFromPatient = () => {
    setSelectedPatientId(null);
  };

  const renderContent = () => {
    // Patient detail view
    if (tab === 'patients' && selectedPatientId) {
      return (
        <PatientDetail 
          patientId={selectedPatientId} 
          onBack={handleBackFromPatient} 
        />
      );
    }

    switch (tab) {
      case 'patients':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Pacientes</h1>
              <p className="text-muted-foreground">
                Gerencie os pacientes da sua clínica
              </p>
            </div>
            <PatientList onPatientClick={handlePatientClick} />
          </div>
        );

      case 'calendar':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Agenda</h1>
              <p className="text-muted-foreground">
                Visualize e gerencie seus agendamentos
              </p>
            </div>
            <CalendarView />
          </div>
        );

      case 'finance':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Financeiro</h1>
              <p className="text-muted-foreground">
                Controle financeiro da sua clínica
              </p>
            </div>
            
            <Tabs value={financeTab} onValueChange={setFinanceTab}>
              <TabsList>
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="reports">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Relatórios
                </TabsTrigger>
                <TabsTrigger value="receipts">
                  <Receipt className="h-4 w-4 mr-2" />
                  Recibos
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview">
                <FinanceOverview onGenerateReceipt={() => {
                  setFinanceTab('receipts');
                  setReceiptModalOpen(true);
                }} />
              </TabsContent>
              
              <TabsContent value="reports">
                <ReportsDashboard />
              </TabsContent>
              
              <TabsContent value="reports">
                <ReportsDashboard />
              </TabsContent>
              
              <TabsContent value="receipts">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div 
                      key={i}
                      className="p-4 rounded-lg border hover:bg-muted/50 cursor-pointer"
                      onClick={() => setReceiptModalOpen(true)}
                    >
                      <p className="font-medium">Recibo #{String(i).padStart(4, '0')}</p>
                      <p className="text-sm text-muted-foreground">
                        Ana Silva • R$ 200,00
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(Date.now() - i * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
            
            <ReceiptGenerator 
              open={receiptModalOpen} 
              onOpenChange={setReceiptModalOpen} 
            />
          </div>
        );

      case 'settings':
        return <SettingsPage />;

      case 'notifications':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Notificações</h1>
              <p className="text-muted-foreground">
                Configure lembretes e alertas
              </p>
            </div>
            <div className="rounded-lg border border-dashed p-8 text-center">
              <p className="text-muted-foreground">
                Sistema de notificações em desenvolvimento...
              </p>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
              <p className="text-muted-foreground">
                Visão geral da sua clínica
              </p>
            </div>

            {/* Stats */}
            <StatsCards />

            {/* Main Content Grid */}
            <div className="grid gap-6 lg:grid-cols-3">
              <UpcomingSessions />
              <RecentPatients onPatientClick={handlePatientClick} />
            </div>

            {/* Finance Chart */}
            <FinanceChart />
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <AppSidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <AppHeader />

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          <div className="animate-fade-in">
            {renderContent()}
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t py-4 px-6 text-center text-sm text-muted-foreground bg-background">
          <p>
            © {new Date().getFullYear()} Clínica Psi - Sistema de Gestão para Psicanalistas
          </p>
        </footer>
      </div>

      {/* Modals */}
      <NewSessionModal />
      <NewPatientModal />
    </div>
  );
}

function LoadingFallback() {
  return (
    <div className="flex h-screen items-center justify-center bg-background">
      <div className="animate-pulse text-muted-foreground">Carregando...</div>
    </div>
  );
}

export default function HomePage() {
  return (
    <AuthGuard>
      <Suspense fallback={<LoadingFallback />}>
        <HomeContent />
      </Suspense>
    </AuthGuard>
  );
}
