'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { 
  Brain,
  CalendarIcon,
  Clock,
  User,
  Mail,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { format, addDays, setHours, setMinutes, startOfDay, isBefore } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface BookingPageProps {
  params: {
    link: string;
  };
}

// Mock therapist data
const mockTherapist = {
  id: 'therapist-1',
  name: 'Dra. Maria Silva',
  crp: 'CRP 06/123456',
  specialty: 'Psicanálise',
  avatar: null,
  sessionDuration: 50,
  sessionFee: 200,
  workingDays: [1, 2, 3, 4, 5], // Monday to Friday
  workingHours: { start: 8, end: 19 },
};

// Generate available slots
const generateAvailableSlots = (date: Date, workingDays: number[], workingHours: { start: number; end: number }) => {
  const dayOfWeek = date.getDay();
  
  // Check if it's a working day
  if (!workingDays.includes(dayOfWeek === 0 ? 7 : dayOfWeek)) {
    return [];
  }

  const slots: { time: Date; available: boolean }[] = [];
  const startOfDayDate = startOfDay(date);

  for (let hour = workingHours.start; hour < workingHours.end; hour++) {
    for (let minute = 0; minute < 60; minute += 50) {
      const slotTime = setMinutes(setHours(startOfDayDate, hour), minute);
      // Randomly mark some slots as unavailable for demo
      const available = Math.random() > 0.3;
      slots.push({ time: slotTime, available });
    }
  }

  return slots;
};

export default function BookingPage({ params }: BookingPageProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [booked, setBooked] = useState(false);
  
  // Form state
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<Date>();
  
  // Patient info
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [lgpdConsent, setLgpdConsent] = useState(false);

  const therapist = mockTherapist;

  // Calculate available slots using useMemo
  const availableSlots = useMemo(() => {
    if (!selectedDate) return [];
    return generateAvailableSlots(
      selectedDate,
      therapist.workingDays,
      therapist.workingHours
    );
  }, [selectedDate, therapist.workingDays, therapist.workingHours]);

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime || !name || !email || !phone || !lgpdConsent) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setBooked(true);
    setLoading(false);
    toast.success('Sessão agendada com sucesso!');
  };

  if (booked) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full text-center">
          <CardContent className="pt-8 pb-8">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Agendamento Confirmado!</h1>
            <p className="text-muted-foreground mb-6">
              Sua sessão foi agendada com sucesso. Você receberá uma confirmação por e-mail.
            </p>
            
            <div className="bg-muted rounded-lg p-4 text-left space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <CalendarIcon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Data</p>
                  <p className="font-medium">
                    {selectedDate && format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Horário</p>
                  <p className="font-medium">
                    {selectedTime && format(selectedTime, 'HH:mm')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Profissional</p>
                  <p className="font-medium">{therapist.name}</p>
                </div>
              </div>
            </div>

            <p className="text-sm text-muted-foreground">
              Um e-mail de confirmação foi enviado para <strong>{email}</strong>
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-semibold">{therapist.name}</h1>
              <p className="text-xs text-muted-foreground">{therapist.crp}</p>
            </div>
          </div>
          <Badge variant="secondary">{therapist.specialty}</Badge>
        </div>
      </header>

      {/* Content */}
      <main className="container max-w-4xl mx-auto px-4 py-8">
        {/* Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div
                className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium',
                  step >= s
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                )}
              >
                {s}
              </div>
              {s < 3 && (
                <div
                  className={cn(
                    'w-12 h-0.5',
                    step > s ? 'bg-primary' : 'bg-muted'
                  )}
                />
              )}
            </div>
          ))}
        </div>

        <Card className="max-w-xl mx-auto">
          <CardHeader>
            <CardTitle>
              {step === 1 && 'Escolha a Data e Horário'}
              {step === 2 && 'Seus Dados'}
              {step === 3 && 'Confirmação'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Date & Time */}
            {step === 1 && (
              <>
                <div className="space-y-2">
                  <Label>Selecione a Data</Label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => {
                      const day = date.getDay();
                      // Disable weekends and past dates
                      return isBefore(date, new Date()) || 
                             day === 0 || 
                             day === 6 ||
                             date > addDays(new Date(), 60);
                    }}
                    locale={ptBR}
                    className="rounded-md border mx-auto"
                  />
                </div>

                {selectedDate && (
                  <div className="space-y-2">
                    <Label>Horários Disponíveis</Label>
                    <div className="grid grid-cols-4 gap-2">
                      {availableSlots.map((slot, index) => (
                        <Button
                          key={index}
                          variant={selectedTime?.getTime() === slot.time.getTime() ? 'default' : 'outline'}
                          size="sm"
                          disabled={!slot.available}
                          onClick={() => setSelectedTime(slot.time)}
                          className={cn(
                            !slot.available && 'opacity-50 cursor-not-allowed'
                          )}
                        >
                          {format(slot.time, 'HH:mm')}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button
                    onClick={() => setStep(2)}
                    disabled={!selectedDate || !selectedTime}
                  >
                    Continuar
                  </Button>
                </div>
              </>
            )}

            {/* Step 2: Patient Info */}
            {step === 2 && (
              <>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Seu nome completo"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone *</Label>
                    <Input
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(11) 99999-9999"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Observações</Label>
                    <Input
                      id="notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Alguma informação adicional..."
                    />
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    Voltar
                  </Button>
                  <Button
                    onClick={() => setStep(3)}
                    disabled={!name || !email || !phone}
                  >
                    Continuar
                  </Button>
                </div>
              </>
            )}

            {/* Step 3: Confirmation */}
            {step === 3 && (
              <>
                <div className="bg-muted rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <CalendarIcon className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Data</p>
                      <p className="font-medium">
                        {selectedDate && format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Horário</p>
                      <p className="font-medium">
                        {selectedTime && format(selectedTime, 'HH:mm')} ({therapist.sessionDuration} min)
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <User className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Paciente</p>
                      <p className="font-medium">{name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">E-mail</p>
                      <p className="font-medium">{email}</p>
                    </div>
                  </div>
                </div>

                {/* LGPD Consent */}
                <div className="flex items-start gap-3 p-4 rounded-lg border">
                  <input
                    type="checkbox"
                    id="lgpd"
                    checked={lgpdConsent}
                    onChange={(e) => setLgpdConsent(e.target.checked)}
                    className="mt-1"
                  />
                  <div className="text-sm">
                    <Label htmlFor="lgpd" className="cursor-pointer font-medium">
                      Consentimento LGPD *
                    </Label>
                    <p className="text-muted-foreground mt-1">
                      Declaro que li e concordo com a coleta e uso dos meus dados pessoais
                      conforme a Lei Geral de Proteção de Dados (Lei nº 13.709/2018).
                    </p>
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(2)}>
                    Voltar
                  </Button>
                  <Button
                    onClick={handleBooking}
                    disabled={!lgpdConsent || loading}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Agendando...
                      </>
                    ) : (
                      'Confirmar Agendamento'
                    )}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="border-t py-6 mt-8">
        <div className="container max-w-4xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Clínica Psi - Sistema de Gestão para Psicanalistas</p>
        </div>
      </footer>
    </div>
  );
}
