import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/notes - Get session notes
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');
    const type = searchParams.get('type');

    const where: Record<string, unknown> = {};
    if (sessionId) where.sessionId = sessionId;
    if (type) where.type = type;

    const notes = await db.sessionNote.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(notes);
  } catch (error) {
    console.error('Fetch notes error:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar notas' },
      { status: 500 }
    );
  }
}

// POST /api/notes - Create encrypted note
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { sessionId, type, content, title, password } = body;

    if (!sessionId || !content) {
      return NextResponse.json(
        { error: 'Sessão e conteúdo são obrigatórios' },
        { status: 400 }
      );
    }

    // In production, encrypt the content with the password
    const note = await db.sessionNote.create({
      data: {
        sessionId,
        type: type || 'clinical',
        contentEncrypted: content,
        title,
      },
    });

    return NextResponse.json(note, { status: 201 });
  } catch (error) {
    console.error('Create note error:', error);
    return NextResponse.json(
      { error: 'Erro ao criar nota' },
      { status: 500 }
    );
  }
}

// PUT /api/notes - Update note
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, content, title } = body;

    if (!id || !content) {
      return NextResponse.json(
        { error: 'ID e conteúdo são obrigatórios' },
        { status: 400 }
      );
    }

    const note = await db.sessionNote.update({
      where: { id },
      data: {
        contentEncrypted: content,
        title,
      },
    });

    return NextResponse.json(note);
  } catch (error) {
    console.error('Update note error:', error);
    return NextResponse.json(
      { error: 'Erro ao atualizar nota' },
      { status: 500 }
    );
  }
}

// DELETE /api/notes - Delete note
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'ID da nota é obrigatório' },
        { status: 400 }
      );
    }

    await db.sessionNote.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete note error:', error);
    return NextResponse.json(
      { error: 'Erro ao excluir nota' },
      { status: 500 }
    );
  }
}
