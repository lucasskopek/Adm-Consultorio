import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/sessions - List all sessions
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const patientId = searchParams.get('patientId');
    const status = searchParams.get('status');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = {};

    if (patientId) {
      where.patientId = patientId;
    }

    if (status) {
      where.status = status;
    }

    if (startDate || endDate) {
      where.scheduledAt = {};
      if (startDate) {
        where.scheduledAt.gte = new Date(startDate);
      }
      if (endDate) {
        where.scheduledAt.lte = new Date(endDate);
      }
    }

    const sessions = await db.session.findMany({
      where,
      include: {
        patient: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
          },
        },
        notes: true,
      },
      orderBy: { scheduledAt: 'desc' },
      take: limit,
      skip: offset,
    });

    return NextResponse.json(sessions);
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar sessões' },
      { status: 500 }
    );
  }
}

// POST /api/sessions - Create new session
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      patientId,
      scheduledAt,
      duration,
      fee,
      notes,
    } = body;

    // For demo purposes, we'll use a default user ID
    const userId = 'default-user';

    // Get the next session number for this patient
    const lastSession = await db.session.findFirst({
      where: { patientId },
      orderBy: { sessionNumber: 'desc' },
    });

    const sessionNumber = (lastSession?.sessionNumber || 0) + 1;

    const session = await db.session.create({
      data: {
        patientId,
        userId,
        sessionNumber,
        scheduledAt: new Date(scheduledAt),
        duration: duration || 50,
        fee: fee || null,
        status: 'scheduled',
      },
      include: {
        patient: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json(session, { status: 201 });
  } catch (error) {
    console.error('Error creating session:', error);
    return NextResponse.json(
      { error: 'Erro ao criar sessão' },
      { status: 500 }
    );
  }
}
