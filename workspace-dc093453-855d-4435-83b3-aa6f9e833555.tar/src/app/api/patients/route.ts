import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/patients - List all patients
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    if (status && status !== 'all') {
      where.status = status;
    }

    const [patients, total] = await Promise.all([
      db.patient.findMany({
        where,
        include: {
          anamnesis: true,
          _count: {
            select: { sessions: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.patient.count({ where }),
    ]);

    return NextResponse.json({
      patients,
      total,
      limit,
      offset,
    });
  } catch (error) {
    console.error('Error fetching patients:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar pacientes' },
      { status: 500 }
    );
  }
}

// POST /api/patients - Create new patient
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      name,
      email,
      phone,
      birthDate,
      gender,
      cpf,
      rg,
      address,
      city,
      state,
      zipCode,
      emergencyName,
      emergencyPhone,
      emergencyRelation,
      maritalStatus,
      occupation,
      education,
      lgpdConsent,
    } = body;

    // For demo purposes, we'll use a default user ID
    const userId = 'default-user';

    const patient = await db.patient.create({
      data: {
        userId,
        name,
        email: email || null,
        phone: phone || null,
        birthDate: birthDate ? new Date(birthDate) : null,
        gender: gender || null,
        cpf: cpf || null,
        rg: rg || null,
        address: address || null,
        city: city || null,
        state: state || null,
        zipCode: zipCode || null,
        emergencyName: emergencyName || null,
        emergencyPhone: emergencyPhone || null,
        emergencyRelation: emergencyRelation || null,
        maritalStatus: maritalStatus || null,
        occupation: occupation || null,
        education: education || null,
        lgpdConsent: lgpdConsent || false,
        lgpdConsentAt: lgpdConsent ? new Date() : null,
      },
    });

    // Create empty anamnesis for the patient
    await db.anamnesis.create({
      data: {
        patientId: patient.id,
      },
    });

    return NextResponse.json(patient, { status: 201 });
  } catch (error) {
    console.error('Error creating patient:', error);
    return NextResponse.json(
      { error: 'Erro ao criar paciente' },
      { status: 500 }
    );
  }
}
