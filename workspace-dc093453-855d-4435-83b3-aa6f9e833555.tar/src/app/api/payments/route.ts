import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/payments - List all payments
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const patientId = searchParams.get('patientId');
    const status = searchParams.get('status');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = {};

    if (patientId) {
      where.patientId = patientId;
    }

    if (status) {
      where.status = status;
    }

    if (startDate || endDate) {
      where.dueDate = {};
      if (startDate) {
        where.dueDate.gte = new Date(startDate);
      }
      if (endDate) {
        where.dueDate.lte = new Date(endDate);
      }
    }

    const [payments, total] = await Promise.all([
      db.payment.findMany({
        where,
        include: {
          patient: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            },
          },
          invoice: true,
        },
        orderBy: { dueDate: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.payment.count({ where }),
    ]);

    // Calculate totals
    const stats = await db.payment.aggregate({
      where,
      _sum: {
        amount: true,
      },
    });

    const pendingTotal = await db.payment.aggregate({
      where: { status: 'pending' },
      _sum: { amount: true },
    });

    const overduePayments = await db.payment.findMany({
      where: {
        status: 'pending',
        dueDate: { lt: new Date() },
      },
      _sum: { amount: true },
    });

    return NextResponse.json({
      payments,
      total,
      stats: {
        total: stats._sum.amount || 0,
        pending: pendingTotal._sum.amount || 0,
        overdue: overduePayments.reduce((acc, p) => acc + (p.amount || 0), 0),
      },
    });
  } catch (error) {
    console.error('Error fetching payments:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar pagamentos' },
      { status: 500 }
    );
  }
}

// POST /api/payments - Create new payment
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      patientId,
      amount,
      method,
      dueDate,
      referenceMonth,
      sessionIds,
      notes,
    } = body;

    // For demo purposes, we'll use a default user ID
    const userId = 'default-user';

    const payment = await db.payment.create({
      data: {
        patientId,
        userId,
        amount: parseFloat(amount),
        method: method || 'cash',
        status: 'pending',
        dueDate: dueDate ? new Date(dueDate) : null,
        referenceMonth: referenceMonth || null,
        sessionIds: sessionIds ? JSON.stringify(sessionIds) : null,
        notes: notes || null,
      },
      include: {
        patient: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json(payment, { status: 201 });
  } catch (error) {
    console.error('Error creating payment:', error);
    return NextResponse.json(
      { error: 'Erro ao criar pagamento' },
      { status: 500 }
    );
  }
}
