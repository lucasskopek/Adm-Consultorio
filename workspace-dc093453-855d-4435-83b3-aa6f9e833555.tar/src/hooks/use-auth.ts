'use client';

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';

interface User {
  id: string;
  email: string;
  name: string;
  crp?: string | null;
  role: string;
}

// Demo user for development
const DEMO_USER: User = {
  id: 'demo-user',
  email: 'demo@clinicapsi.com',
  name: 'Dra. Maria Silva',
  crp: 'CRP 06/123456',
  role: 'therapist',
};

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Check for demo mode or session
    const checkAuth = async () => {
      try {
        // For demo purposes, auto-login
        const isDemoMode = true;
        
        if (isDemoMode) {
          setUser(DEMO_USER);
        } else {
          // In production, check NextAuth session
          // const session = await fetch('/api/auth/session').then(r => r.json());
          // setUser(session?.user || null);
          setUser(null);
        }
      } catch (error) {
        console.error('Auth check error:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // In production, call NextAuth signIn
      // For demo, accept demo credentials
      if (email === 'demo@clinicapsi.com' && password === 'demo123') {
        setUser(DEMO_USER);
        router.push('/');
        return { success: true };
      }
      return { success: false, error: 'Credenciais inválidas' };
    } catch (error) {
      return { success: false, error: 'Erro ao fazer login' };
    }
  };

  const logout = async () => {
    try {
      // In production, call NextAuth signOut
      setUser(null);
      router.push('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return {
    user,
    loading,
    login,
    logout,
    isAuthenticated: !!user,
  };
}
