import { PrismaClient } from '@prisma/client';
import { createHash } from 'crypto';

const prisma = new PrismaClient();

async function main() {
  const user = await prisma.user.findUnique({
    where: { email: 'admin@clinicapsi.com' }
  });
  
  if (user) {
    console.log('User found:');
    console.log('Email:', user.email);
    console.log('Name:', user.name);
    console.log('Password hash:', user.passwordHash);
    console.log('Hash length:', user.passwordHash?.length);
    
    // Test hash
    const testHash = createHash('sha256').update('admin123').digest('hex');
    console.log('\nExpected hash for "admin123":', testHash);
    console.log('Hashes match:', testHash === user.passwordHash);
  } else {
    console.log('User not found!');
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
