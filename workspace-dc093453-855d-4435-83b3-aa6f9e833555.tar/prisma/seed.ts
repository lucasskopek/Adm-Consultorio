import { PrismaClient } from '@prisma/client';
import { createHash } from 'crypto';

const prisma = new PrismaClient();

// Simple SHA-256 password hashing (matches the auth.ts implementation)
function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

async function main() {
  console.log('🌱 Seeding database...');

  // Create default user with SHA-256 hash
  const hashedPassword = hashPassword('admin123');
  
  const user = await prisma.user.upsert({
    where: { email: 'admin@clinicapsi.com' },
    update: {},
    create: {
      email: 'admin@clinicapsi.com',
      name: 'Dr. Silva',
      passwordHash: hashedPassword,
      role: 'admin',
      crp: '06/123456',
      specialty: 'Psicanálise Clínica',
      phone: '(11) 99999-9999',
      lgpdConsent: true,
      lgpdConsentAt: new Date(),
      settings: {
        theme: 'light',
        language: 'pt-BR',
        sessionDuration: 50,
        sessionFee: 200,
        currency: 'BRL',
        notifications: {
          email: true,
          whatsapp: true,
          reminderBefore: 24
        }
      }
    }
  });

  console.log('✅ User created:', user.email);
  console.log('   Password: admin123');

  // Check if patients already exist
  const existingPatients = await prisma.patient.count();
  
  if (existingPatients > 0) {
    console.log('⏭️ Patients already exist, skipping...');
    return;
  }

  // Create some sample patients
  const patients = await Promise.all([
    prisma.patient.create({
      data: {
        userId: user.id,
        name: 'Maria Santos',
        email: 'maria@email.com',
        phone: '(11) 98888-8888',
        birthDate: new Date('1985-03-15'),
        gender: 'female',
        cpf: '123.456.789-00',
        status: 'active',
        maritalStatus: 'married',
        occupation: 'Advogada',
        address: 'Rua das Flores, 123',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        emergencyName: 'João Santos',
        emergencyPhone: '(11) 97777-7777',
        emergencyRelation: 'Esposo',
        lgpdConsent: true,
        lgpdConsentAt: new Date()
      }
    }),
    prisma.patient.create({
      data: {
        userId: user.id,
        name: 'Pedro Oliveira',
        email: 'pedro@email.com',
        phone: '(11) 96666-6666',
        birthDate: new Date('1990-07-22'),
        gender: 'male',
        status: 'active',
        maritalStatus: 'single',
        occupation: 'Engenheiro',
        city: 'São Paulo',
        state: 'SP',
        lgpdConsent: true,
        lgpdConsentAt: new Date()
      }
    }),
    prisma.patient.create({
      data: {
        userId: user.id,
        name: 'Ana Costa',
        email: 'ana@email.com',
        phone: '(11) 95555-5555',
        birthDate: new Date('1995-11-10'),
        gender: 'female',
        status: 'active',
        maritalStatus: 'single',
        occupation: 'Designer',
        city: 'São Paulo',
        state: 'SP',
        lgpdConsent: true,
        lgpdConsentAt: new Date()
      }
    })
  ]);

  console.log(`✅ Created ${patients.length} patients`);

  // Create appointments for the next week
  const now = new Date();
  const appointments = [];
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() + i);
    date.setHours(10, 0, 0, 0);
    
    // Morning session
    appointments.push(
      prisma.appointment.create({
        data: {
          userId: user.id,
          patientId: patients[i % patients.length].id,
          title: `Sessão - ${patients[i % patients.length].name}`,
          startTime: date,
          endTime: new Date(date.getTime() + 50 * 60 * 1000),
          status: i === 0 ? 'confirmed' : 'scheduled'
        }
      })
    );
    
    // Afternoon session
    const afternoonDate = new Date(date);
    afternoonDate.setHours(15, 0, 0, 0);
    appointments.push(
      prisma.appointment.create({
        data: {
          userId: user.id,
          patientId: patients[(i + 1) % patients.length].id,
          title: `Sessão - ${patients[(i + 1) % patients.length].name}`,
          startTime: afternoonDate,
          endTime: new Date(afternoonDate.getTime() + 50 * 60 * 1000),
          status: 'scheduled'
        }
      })
    );
  }

  await Promise.all(appointments);
  console.log(`✅ Created ${appointments.length} appointments`);

  // Create some payments
  const payments = await Promise.all([
    prisma.payment.create({
      data: {
        userId: user.id,
        patientId: patients[0].id,
        amount: 200,
        method: 'pix',
        status: 'paid',
        referenceMonth: new Date().toISOString().slice(0, 7),
        paidAt: new Date()
      }
    }),
    prisma.payment.create({
      data: {
        userId: user.id,
        patientId: patients[1].id,
        amount: 200,
        method: 'cash',
        status: 'paid',
        referenceMonth: new Date().toISOString().slice(0, 7),
        paidAt: new Date()
      }
    }),
    prisma.payment.create({
      data: {
        userId: user.id,
        patientId: patients[2].id,
        amount: 200,
        method: 'credit',
        status: 'pending',
        referenceMonth: new Date().toISOString().slice(0, 7),
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      }
    })
  ]);

  console.log(`✅ Created ${payments.length} payments`);

  console.log('🎉 Seed completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
